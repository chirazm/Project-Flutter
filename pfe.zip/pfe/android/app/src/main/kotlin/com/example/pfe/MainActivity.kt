package com.example.pfe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
