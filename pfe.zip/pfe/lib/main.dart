import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pfe/Identification/Identification.dart';
import 'Interface_Parent/Home/Home.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp (
      theme: new ThemeData(
          primaryColor: Colors.purple,
          accentColor: Colors.white),
      home:  Identification()
    );

  }
}