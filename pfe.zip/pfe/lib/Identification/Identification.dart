import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Fade_animation.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Ajouter_Ecole.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:pfe/Interface_Professeur/Accueil_Professeur/accueil.dart';

class Identification extends StatefulWidget {
  @override
  _IdentificationState createState() => _IdentificationState();
}

class _IdentificationState extends State<Identification> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _email, _password;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
              Container(
                height: 400,
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: -40,
                      height: 400,
                      width: width,
                      child: FadeAnimation(
                          1,
                          Container(
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage(
                                        'assets/images/background-1.png'),
                                    fit: BoxFit.fill)),
                          )),
                    ),
                    Positioned(
                      height: 400,
                      width: width + 20,
                      child: FadeAnimation(
                          1.3,
                          Container(
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage(
                                        'assets/images/background-2.png'),
                                    fit: BoxFit.fill)),
                          )),
                    ),
                    Positioned(
                        child: FadeAnimation(
                            1.6,
                            Container(
                              margin: EdgeInsets.only(top: 10, bottom: 50),
                              child: Center(
                                child: Text(
                                  "Bienvenue",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 40,
                                      fontWeight: FontWeight.bold,
                                      fontStyle: FontStyle.italic),
                                ),
                              ),
                            ))),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(30.0),
                child: Column(
                  children: <Widget>[
                    FadeAnimation(
                        1.8,
                        Container(
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(143, 148, 251, .2),
                                    blurRadius: 20.0,
                                    offset: Offset(0, 10))
                              ]),
                        )),
                    Form(
                      key: _formKey,
                      child: Column(children: <Widget>[
                        Container(
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                              border: Border(
                                  bottom: BorderSide(color: Colors.grey[100]))),
                          child: TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            validator: (item) {
                              return item.contains("@")
                                  ? null
                                  : "Enter valid Email";
                            },
                            onChanged: (item) {
                              setState(() {
                                _email = item;
                              });
                            },
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.black, width: 5.0),
                                ),
                                hintText: "Email",
                                hintStyle: TextStyle(color: Colors.grey[400])),
//                                    onSaved: (input) => _email = input,
                          ),
                        ),
                      ]),
                    ),
                    Container(
                      padding: EdgeInsets.all(8.0),
                      child: TextFormField(
                        obscureText: true,
                        validator: (item) {
                          return item.contains("")
                              ? null
                              : "Enter mot de passe";
                        },

                        onChanged: (item) {
                          setState(() {
                            _password = item;
                          });
                        },
                        autocorrect: false,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.black, width: 5.0),
                            ),
                            hintText: "Mot de passe",
                            hintStyle: TextStyle(color: Colors.grey[400])),
//                            onSaved: (input) => _password = input,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 40, right: 35),
                      child: FadeAnimation(
                          2,
                          MaterialButton(
                            height: 50,
                            onPressed: () {
                              signIn();
                            },
                            color: Colors.purple[900],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Text(
                                "S'identifier",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 22),
                              ),
                            ),
                          )),
                    ),
                    SizedBox(
                      height: 70,
                    ),
                  ],
                ),
              )
            ])));
  }

  Future<void> signIn() async {
    if (_formKey.currentState.validate()) {
      setState(() {
        isLoading = true;
      });
      FirebaseAuth.instance
          .signInWithEmailAndPassword(email: _email, password: _password);
//          .then((user) {
      // sign up
//        var uid = user.uid;
      FirebaseAuth.instance.currentUser().then((user) {
        Firestore.instance
            .collection('users')
            .where('id', isEqualTo: user.uid)
            .getDocuments()
            .then((docs) {
          if (docs.documents[0].exists) {
            if (docs.documents[0].data['role'] == 'parent') {
              setState(() {
                isLoading = false;
              });
              Fluttertoast.showToast(msg: "Login Success");
              Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) => new AjouterEcole()));

            } else {
              if (docs.documents[0].data['role'] == 'professeur') {
                setState(() {
                  isLoading = false;
                });
                Fluttertoast.showToast(msg: "Login Success");
                Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) => new AccueilProf()));
              }
            }
          }
        });
//        authorizedAccess(context);
//        findUser(uid);

//        Navigator.pushAndRemoveUntil(
//            context,
//            MaterialPageRoute(builder: (_) => Ajouter_Ecole()),
//                (Route<dynamic> route) => false);
      }).catchError((onError) {
        setState(() {
          isLoading = false;
        });
        Fluttertoast.showToast(msg: "error " + onError.toString());
      });
    }
  }

//  Future findUser(String uid) async {
//    var firestore = Firestore.instance;
//    Query ref  = firestore.collection("users").where(uid == 'id');
//    print(ref.getDocuments());
//
//
//  }
//authorizedAccess (BuildContext context){
//    FirebaseAuth.instance.currentUser().then((user){
//    Firestore.instance.collection('/users')
//        .where('id', isEqualTo: user.uid)
//        .getDocuments()
//        .then((docs) {
//         if(docs.documents[0].exists){
//           if(docs.documents[0].data['role'] == 'parent'){
//             Navigator.of(context).push(
//                 new MaterialPageRoute(
//                     builder: (BuildContext context) => new Ajouter_Ecole()
//                 ));
//           } else {
//             if(docs.documents[0].data['role'] == 'professeur'){
//               Navigator.of(context).push(
//                   new MaterialPageRoute(
//                       builder: (BuildContext context) => new hoome()
//                   ));
//           }
//         }
//    }});
//      });
//}
}

//
//child: Column(
//children: <Widget>[
//Container(
//padding: EdgeInsets.all(8.0),
//decoration: BoxDecoration(
//border: Border(bottom: BorderSide(color: Colors.grey[100]))
//),
//child: TextField(
//decoration: InputDecoration(
//border: OutlineInputBorder(
//borderSide: BorderSide(
//color: Colors.black,
//width: 5.0),
//),
//hintText: "Email",
//hintStyle: TextStyle(color: Colors.grey[400])
//),
//),
//),
//Container(
//padding: EdgeInsets.all(8.0),
//child: TextField(
//autocorrect: false,
//decoration: InputDecoration(
//border: OutlineInputBorder(
//borderSide: BorderSide(
//color: Colors.black,
//width: 5.0),
//),
//hintText: "Mot de passe",
//hintStyle: TextStyle(color: Colors.grey[400])
//),
//),
//)
//],
//),
//)),
//SizedBox(height: 30,),
//FadeAnimation(2, MaterialButton(
//height: 50,
//onPressed: () {
//Navigator.push(context, MaterialPageRoute(builder: (context) => Ajouter_Ecole()));
//},
//color: Colors.indigo,
//shape: RoundedRectangleBorder(
//borderRadius: BorderRadius.circular(10),
//),
//child: Center(
//child: Text("S'identifier",
//style: TextStyle(
//color: Colors.white,
//fontWeight: FontWeight.bold,
//fontSize: 22
//),),
//),
//)),
//SizedBox(height: 70,),
