import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Fade_animation.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Identification.dart';
import 'package:pfe/Interface_Parent/Home/Home.dart';

class AjouterEcole extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        elevation: 0,
        brightness: Brightness.light,
        backgroundColor: Colors.grey[100],
        leading: IconButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => Identification()));
          },
          icon: Icon(
            Icons.arrow_back,
            size: 28,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 15,
                    ),
                    FadeAnimation(
                        1,
                        Text(
                          "Ajouter Ecole",
                          style: TextStyle(
                              fontSize: 33,
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.italic),
                        )),
                    SizedBox(
                      height: 20,
                    ),
                    FadeAnimation(
                        1.4,
                        CircleAvatar(
                          backgroundImage:
                              AssetImage('assets/images/Ecole.jpg'),
                          radius: 100,
                        )),
                    SizedBox(height: 25),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      child: Column(
                        children: <Widget>[
                          FadeAnimation(1.2, makeInput(label: "Identifiant")),
                          FadeAnimation(
                              1.3,
                              makeInput(
                                  label: "Mot de passe", obscureText: true)),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 28,
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 80, right: 75),
                      child: FadeAnimation(
                          2,
                          MaterialButton(
                            height: 50,
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Home()));
                            },
                            color: Colors.purple[900],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Text(
                                "Ajouter",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 22),
                              ),
                            ),
                          )),
                    )
                  ],
                ),
              ),
//            FadeAnimation(1.2, Container(
//              height: MediaQuery.of(context).size.height / 3,
//              decoration: BoxDecoration(
//                  image: DecorationImage(
//                      image: AssetImage('assets/images/Ecole.jpg'),
//                      fit: BoxFit.cover
//                  )
//              ),
//            ))
            ]),
      ),
    );
  }

  Widget makeInput({label, obscureText = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          label,
          style: TextStyle(
              fontSize: 18, fontWeight: FontWeight.w400, color: Colors.black87),
        ),
        SizedBox(
          height: 5,
        ),
        TextField(
          obscureText: obscureText,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 10),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey[400])),
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey[400])),
          ),
        ),
        SizedBox(
          height: 30,
        ),
      ],
    );
  }
}
