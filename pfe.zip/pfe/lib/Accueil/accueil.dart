//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:pfe/Accueil/utilisateur.dart';
//import 'package:pfe/Accueil/Fade_animation.dart';
//import 'package:pfe/Interface_Parent/Identification/Identification.dart';
//import 'package:pfe/Interface_Professeur/Identification/identification.dart';
//class Accueil extends StatefulWidget {
//  @override
//  _AccueilState  createState() => _AccueilState();
//}
//
//class _AccueilState extends State<Accueil> {
////  int selectedRadio;
////  List<User> users;
////  User selectedUser;
////
////  @override
////  void initState() {
////    super.initState();
////    selectedRadio = 0;
////    users = User.getUsers();
////  }
////  setSelectedRadio(int val) {
////    setState(() {
////      selectedRadio = val;
////    });
////  }
////  setSelectedUser(User user) {
////    setState(() {
////      selectedUser = user;
////    });
////  }
////  List<Widget> createRadioListUsers() {
////    List<Widget> widgets = [];
////    for (User user in users) {
////      widgets.add(
////        RadioListTile(
////          value: user,
////          groupValue: selectedUser,
////          title: Text(user.firstName,
////            style: TextStyle(
////                fontSize: 18
////            ),),
////          onChanged: (currentUser) {
////            setSelectedUser(currentUser);
////          },
////          selected: selectedUser == user,
////          activeColor: Colors.purple,
////        ),
////      );
////    }
////    return widgets;
////  }
//  Widget build(BuildContext context) {
//    final width = MediaQuery.of(context).size.width;
//    return Scaffold(
//        backgroundColor: Colors.white,
//        body: SingleChildScrollView(
//            child: Column(
//              crossAxisAlignment: CrossAxisAlignment.start,
//              children: <Widget>[
//                Container(
//                  height: 400,
//                  child: Stack(
//                    children: <Widget>[
//                      Positioned(
//                        top: -40,
//                        height: 400,
//                        width: width,
//                        child: FadeAnimation(1, Container(
//                          decoration: BoxDecoration(
//                              image: DecorationImage(
//                                  image: AssetImage('assets/images/background-1.png'),
//                                  fit: BoxFit.fill
//                              )
//                          ),
//                        )),
//                      ),
//                      Positioned(
//                        height: 400,
//                        width: width+20,
//                        child: FadeAnimation(1.3, Container(
//                          decoration: BoxDecoration(
//                              image: DecorationImage(
//                                  image: AssetImage('assets/images/background-2.png'),
//                                  fit: BoxFit.fill
//                              )
//                          ),
//                        )),
//                      ),
//                      Positioned(
//                          child: FadeAnimation(1.6, Container(
//                            margin: EdgeInsets.only(top: 10,bottom: 50),
//                            child: Center(
//                              child: Text("Bienvenue",
//                                style: TextStyle(
//                                    color: Colors.white,
//                                    fontSize: 50,
//                                    fontWeight: FontWeight.bold,
//                                    fontStyle: FontStyle.italic
//                                ),),),
//                          ))),
//                    ],
//                  ),
//                ),
//
////                Container(
////                  padding: EdgeInsets.all(20.0),
////                  child: Text("Utilisateurs :",
////                    style: TextStyle(
////                        fontSize: 20,
////                        fontWeight: FontWeight.bold
////                    ),),
////                ),
////                Column(
////
////                  children: createRadioListUsers(),
////                ),
//                Container(
//                  alignment: Alignment.center,
//                  margin: EdgeInsets.only(top: 50),
//                  child : MaterialButton(
//                    padding: EdgeInsets.only(right: 70,left: 70),
//                    height: 60,
//                    onPressed: () {
//                      Navigator.push(context, MaterialPageRoute(builder: (context) => IdentificationParent()));
//                    },
//                    color: Colors.purple[900],
//                    elevation: 0,
//                    shape: RoundedRectangleBorder(
//                        borderRadius: BorderRadius.circular(50)
//                    ),
//                    child: Text("Parent",
//                      style: TextStyle(
//                          fontWeight: FontWeight.w600,
//                          fontSize: 22,
//                          color: Colors.white
//                      ),),
//                  ),),
//                Container(
//                  alignment: Alignment.center,
//                  margin: EdgeInsets.only(top: 50),
//                  child : MaterialButton(
//                    padding: EdgeInsets.only(right: 50,left: 50),
//                    height: 60,
//                    onPressed: () {
//                      Navigator.push(context, MaterialPageRoute(builder: (context) => IdentificationProf()));
//                    },
//                    color: Colors.purple[900],
//                    elevation: 0,
//                    shape: RoundedRectangleBorder(
//                        borderRadius: BorderRadius.circular(50)
//                    ),
//                    child: Text("Professeur",
//                      style: TextStyle(
//                          fontWeight: FontWeight.w600,
//                          fontSize: 22,
//                          color: Colors.white
//                      ),),
//                  ),),
//
//              ],
//            )
//        )
//
//    );
//
//  }}
//
//
