class User {
  int userId;
  String firstName;

  User({this.userId, this.firstName});

  static List<User> getUsers() {
    return <User>[
      User(userId: 1, firstName: "Parent"),
      User(userId: 2, firstName: "Professeur"),
    ];
  }
}