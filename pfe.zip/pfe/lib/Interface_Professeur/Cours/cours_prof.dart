import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class cours_prof extends StatefulWidget {
  @override
  _cours_profState createState() => _cours_profState();
}

class _cours_profState extends State<cours_prof> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
