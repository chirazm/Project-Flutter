import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class messages_prof extends StatefulWidget {
  @override
  _messages_profState createState() => _messages_profState();
}

class _messages_profState extends State<messages_prof> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
