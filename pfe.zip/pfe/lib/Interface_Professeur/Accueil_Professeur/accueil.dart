import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:pfe/Interface_Professeur/Calendrier/calendrier_prof.dart';
import 'package:pfe/Interface_Professeur/Messages/messages_prof.dart';
import 'package:pfe/Interface_Professeur/Cours/cours_prof.dart';
class AccueilProf extends StatefulWidget {
  @override
  _AccueilProfState createState() => _AccueilProfState();
}

class _AccueilProfState extends State<AccueilProf> {
  int _currentIndex = 0;
  final List<Widget> _children = [
    CalendrierProf(),
    messages_prof (),
    cours_prof(),
  ];
  void onTappedBar (int index){
    setState(() {
      _currentIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    _children [_currentIndex];
    Widget _flexibleSpace =

    Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[350],
        title: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          Image.asset(
            'assets/images/oschoo.png',
            fit: BoxFit.contain,
            height: 70,
            width: 90,
          ),
        ]),
      ),
      drawer: new Drawer(
          child: new ListView(
        children: <Widget>[
          new UserAccountsDrawerHeader(
            accountName: new Text(
              "Mzali Rania",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            accountEmail: new Text("mzalirania@hotmail.com"),
            currentAccountPicture: new CircleAvatar(
              backgroundColor: Colors.grey[200],
              backgroundImage: AssetImage('assets/images/utilisateur.jpg'),
            ),
          ),
          new ListTile(
            title: new Text(
              "Ajouter école",
              style: TextStyle(fontSize: 17),
            ),
            trailing: new Icon(Icons.home),
//    onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=> new Ajouter_Ecole())),
          ),
          new ListTile(
            title: new Text("Paramétres", style: TextStyle(fontSize: 17)),
            trailing: new Icon(Icons.settings),
          ),
          new ListTile(
            title: new Text("A propos", style: TextStyle(fontSize: 17)),
            trailing: new Icon(Icons.error),
//    onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=> new AboutUs())),
          ),
          new Divider(
            color: Colors.black45,
            indent: 17,
          ),
          new ListTile(
              title: new Text("Déconnexion", style: TextStyle(fontSize: 17)),
              trailing: new Icon(Icons.exit_to_app),
              onTap: () async {
//    await _auth.signOut();
              }),
        ],
      )),
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTappedBar,

        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.calendar_today,
              size: 30,
            ),
            title: Text(
              'Calendrier',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.mail,
              size: 30,
            ),
            title: Text(
              'Messages',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.picture_as_pdf,
              size: 30,
            ),
            title: Text(
              'Cours',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
        ],
        unselectedItemColor: Colors.purple[300],
        selectedItemColor: Colors.purple.shade800,
        showUnselectedLabels: true,
        showSelectedLabels: true,
        backgroundColor: Colors.grey[400],
        type: BottomNavigationBarType.fixed,
        selectedFontSize: 17.0,
        unselectedFontSize: 15.0,
      ),
      body: _children [_currentIndex],
    );
    return _flexibleSpace;

  }
}
