import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class CalendrierProf extends StatefulWidget {
  @override
  _CalendrierProfState createState() => _CalendrierProfState();
}

class _CalendrierProfState extends State<CalendrierProf> {
  Future getCalendrier() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = (await firestore
        .collection("dbprofesseur")
        .document("Calendrier")
        .get()) as QuerySnapshot;
    return qn.documents;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 50),
          alignment: Alignment.topCenter,
          color: Color(0xFFF0F0F0),
          height: MediaQuery.of(context).size.height,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.calendar_today, color: Colors.grey),
                  SizedBox(
                    width: 15,
                  ),
                  RichText(
                    text: TextSpan(
                        text: "Année scolaire :",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0XFF263064),
                          fontSize: 22,
                        ),
                        children: [
                          TextSpan(
                            text: " 2019/2020",
                            style: TextStyle(
                              fontWeight: FontWeight.normal,
                              fontSize: 16,
                            ),
                          ),
                        ]),
                  ),
                ],
              ),
            ],
          ),
        ),
        Positioned(
            top: 100,
            child: Container(
              height: MediaQuery.of(context).size.height - 160,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
              ),
              child: GridView(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 0,
                      crossAxisSpacing: 0,
                      childAspectRatio: 1),
                  scrollDirection: Axis.vertical,
                  children: [
                    Card(
                      color: Colors.deepOrange,
                      child: Center(
                        child: Text(
                          "Gride 1",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
//            Column(
//              children: [
//                Container(
//                  margin: EdgeInsets.only(top: 15, bottom: 30),
//                  padding: EdgeInsets.symmetric(horizontal: 15),
//                  child: Row(
//                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                    children: [
//                      buildDateColumn("Lun", false),
//                      buildDateColumn("Mar", false),
//                      buildDateColumn("Mer", false),
//                      buildDateColumn("Jeu", true),
//                      buildDateColumn("Ven", false),
//                      buildDateColumn("Sam", false),
//                    ],
//                  ),
//                ),
//                Expanded(
//                  child: SingleChildScrollView(
//                    child: Container(
//                        margin: EdgeInsets.only(bottom: 25),
//                        child: FutureBuilder(
//                            future: getCalendrier(),
//                            builder: (_, snapshot) {
//                              if (snapshot.connectionState == ConnectionState.waiting) {
//                                return Center(child: Text("Loading ..."));
//                              } else
//                                return ListView.builder(
//                                    itemCount: snapshot.data.length,
//                                    itemBuilder: (_, index) {
//                                      return Column(
//                                        children: [
//                                          Row(
//                                            children: [
//                                              Container(
//                                                width: 15,
//                                                height: 10,
//                                                decoration: BoxDecoration(
//                                                    color: Colors.orange,
//                                                    borderRadius: BorderRadius.horizontal(
//                                                      right: Radius.circular(5),
//                                                    )),
//                                              ),
//                                              SizedBox(
//                                                width: 15,
//                                              ),
//                                              Container(
//                                                width: MediaQuery.of(context).size.width - 60,
//                                                child: Row(
//                                                  mainAxisAlignment:
//                                                  MainAxisAlignment.spaceBetween,
//                                                  children: [
//                                                    RichText(
//                                                      text: TextSpan(
//                                                        text: snapshot.data[index].data["début"],
//                                                        style: TextStyle(
//                                                          fontWeight: FontWeight.bold,
//                                                          color: Colors.black,
//                                                        ),
//                                                      ),
//                                                    ),
//                                                    Text(
//                                                      snapshot.data[index].data["durée"],
//                                                      style: TextStyle(
//                                                        color: Colors.grey,
//                                                      ),
//                                                    )
//                                                  ],
//                                                ),
//                                              )
//                                            ],
//                                          ),
//                                          SizedBox(
//                                            height: 10,
//                                          ),
//                                          Container(
//                                            height: 185,
//                                            width: double.infinity,
//                                            decoration: BoxDecoration(
//                                                border: Border.all(
//                                                    width: 1, color: Colors.grey[300]),
//                                                borderRadius: BorderRadius.circular(20)),
//                                            margin: EdgeInsets.only(right: 10, left: 30),
//                                            padding: EdgeInsets.all(20),
//                                            child: Column(
//                                              crossAxisAlignment: CrossAxisAlignment.start,
//                                              children: [
//                                                Text(
//                                                   snapshot.data[index].data["cours"],
//                                                  style: TextStyle(
//                                                    fontWeight: FontWeight.bold,
//                                                    fontSize: 15,
//                                                  ),
//                                                ),
//                                                SizedBox(
//                                                  height: 15,
//                                                ),
//                                                Row(
//                                                  crossAxisAlignment: CrossAxisAlignment.start,
//                                                  children: [
//                                                    SizedBox(
//                                                      width: 5,
//                                                    ),
//                                                    Column(
//                                                      crossAxisAlignment:
//                                                      CrossAxisAlignment.start,
//                                                      children: [
//                                                        Text(
//                                                          "Gabriel Sutton",
//                                                          style: TextStyle(
//                                                            fontSize: 15,
//                                                          ),
//                                                        ),
//                                                        SizedBox(
//                                                          height: 5,
//                                                        ),
//                                                      ],
//                                                    )
//                                                  ],
//                                                ),
//                                                SizedBox(
//                                                  height: 15,
//                                                ),
//                                                Row(
//                                                  crossAxisAlignment: CrossAxisAlignment.start,
//                                                  children: [
//                                                    Column(
//                                                      crossAxisAlignment:
//                                                      CrossAxisAlignment.start,
//                                                      children: [
//                                                        Text(
//                                                          "Salle :",
//                                                          style: TextStyle(
//                                                            fontSize: 15,
//                                                          ),
//                                                        ),
//                                                        SizedBox(
//                                                          height: 5,
//                                                        ),
//                                                        Text(
//                                                          "Room C1, 1st floor",
//                                                          style: TextStyle(
//                                                            color: Colors.grey,
//                                                            fontSize: 12,
//                                                          ),
//                                                        ),
//                                                      ],
//                                                    )
//                                                  ],
//                                                )
//                                              ],
//                                            ),
//                                          )
//                                        ],
//                                      );
//                                    });
//                            })),
//                  ),
//                )
//              ],
//            ),
                  ]),
            ))
      ],
    );
  }

//  Container buildTaskListItem() {
//    return Container(
//        margin: EdgeInsets.only(bottom: 25),
//        child: FutureBuilder(
//            future: getCalendrier(),
//            builder: (_, snapshot) {
//              if (snapshot.connectionState == ConnectionState.waiting) {
//                return Center(child: Text("Loading ..."));
//              } else
//                return ListView.builder(
//                    itemCount: snapshot.data.length,
//                    itemBuilder: (_, index) {
//                      return Column(
//                        children: [
//                          Row(
//                            children: [
//                              Container(
//                                width: 15,
//                                height: 10,
//                                decoration: BoxDecoration(
//                                    color: Colors.orange,
//                                    borderRadius: BorderRadius.horizontal(
//                                      right: Radius.circular(5),
//                                    )),
//                              ),
//                              SizedBox(
//                                width: 15,
//                              ),
//                              Container(
//                                width: MediaQuery.of(context).size.width - 60,
//                                child: Row(
//                                  mainAxisAlignment:
//                                      MainAxisAlignment.spaceBetween,
//                                  children: [
//                                    RichText(
//                                      text: TextSpan(
//                                          text: snapshot.data[index].data["début"],
//                                          style: TextStyle(
//                                            fontWeight: FontWeight.bold,
//                                            color: Colors.black,
//                                          ),
//                                      ),
//                                    ),
//                                    Text(
//                                      snapshot.data[index].data["durée"],
//                                      style: TextStyle(
//                                        color: Colors.grey,
//                                      ),
//                                    )
//                                  ],
//                                ),
//                              )
//                            ],
//                          ),
//                          SizedBox(
//                            height: 10,
//                          ),
//                          Container(
//                            height: 185,
//                            width: double.infinity,
//                            decoration: BoxDecoration(
//                                border: Border.all(
//                                    width: 1, color: Colors.grey[300]),
//                                borderRadius: BorderRadius.circular(20)),
//                            margin: EdgeInsets.only(right: 10, left: 30),
//                            padding: EdgeInsets.all(20),
//                            child: Column(
//                              crossAxisAlignment: CrossAxisAlignment.start,
//                              children: [
//                                Text(
//                                  "Typography",
//                                  style: TextStyle(
//                                    fontWeight: FontWeight.bold,
//                                    fontSize: 15,
//                                  ),
//                                ),
//                                SizedBox(
//                                  height: 15,
//                                ),
//                                Row(
//                                  crossAxisAlignment: CrossAxisAlignment.start,
//                                  children: [
//                                    SizedBox(
//                                      width: 5,
//                                    ),
//                                    Column(
//                                      crossAxisAlignment:
//                                          CrossAxisAlignment.start,
//                                      children: [
//                                        Text(
//                                          "Gabriel Sutton",
//                                          style: TextStyle(
//                                            fontSize: 15,
//                                          ),
//                                        ),
//                                        SizedBox(
//                                          height: 5,
//                                        ),
//                                      ],
//                                    )
//                                  ],
//                                ),
//                                SizedBox(
//                                  height: 15,
//                                ),
//                                Row(
//                                  crossAxisAlignment: CrossAxisAlignment.start,
//                                  children: [
//                                    Column(
//                                      crossAxisAlignment:
//                                          CrossAxisAlignment.start,
//                                      children: [
//                                        Text(
//                                          "Salle :",
//                                          style: TextStyle(
//                                            fontSize: 15,
//                                          ),
//                                        ),
//                                        SizedBox(
//                                          height: 5,
//                                        ),
//                                        Text(
//                                          "Room C1, 1st floor",
//                                          style: TextStyle(
//                                            color: Colors.grey,
//                                            fontSize: 12,
//                                          ),
//                                        ),
//                                      ],
//                                    )
//                                  ],
//                                )
//                              ],
//                            ),
//                          )
//                        ],
//                      );
//                    });
//            }));
//  }

  Container buildDateColumn(String weekDay, bool isActive) {
    return Container(
      decoration: isActive
          ? BoxDecoration(
              color: Color(0xff402fcc), borderRadius: BorderRadius.circular(10))
          : BoxDecoration(),
      height: 55,
      width: 45,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text(
            weekDay,
            style: TextStyle(color: Colors.grey, fontSize: 16),
          ),
        ],
      ),
    );
  }
}
