//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:pfe/Messages/Contacts_Favoris.dart';
//import 'package:pfe/Messages/recent_chats.dart';
//
//class Messages extends StatefulWidget {
//  @override
//  _MessagesState  createState() => _MessagesState();
//}
//
//class _MessagesState extends State<Messages> {
//  @override
//  Widget build(BuildContext context) {
//    return new Scaffold(
//      backgroundColor: Theme.of(context).accentColor,
//      body: Column(
//        children: <Widget>[
//          SizedBox(height: 30),
////          CategorySelector(),
//          Expanded(
//            child: Container(
//              decoration: BoxDecoration(
//                  color: Theme.of(context).accentColor,
//                  borderRadius: BorderRadius.only(
//                    topRight: Radius.circular(30.0),
//                    topLeft: Radius.circular(30.0),
//                  )
//              ),
//              child: Column(
//                children: <Widget>[
////                  ContactsFavoris(),
//                  RecentChats(),
//                ],
//              ),
//            ),
//          ),
//        ],
//      ),
//    );
//
//  }
//
//}