import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pfe/Interface_Parent/Messages/Utilisateur.dart';

class Message {
  final String sender;
  final String id;
  final String receiver;
  final Timestamp time;
  final String text;
  final bool isLiked;
  final bool unread;
  final String imageUrl;

  Message({
    this.id,
    this.receiver,
    this.sender,
    this.time,
    this.isLiked,
    this.text,
    this.unread,
    this.imageUrl
  });
  factory Message.fromDoc(DocumentSnapshot doc){
    return Message(
      id: doc.documentID,
      sender: doc['sender'],
      receiver: doc['receiver'],
      text: doc['text'],
      isLiked: doc['isLiked'],
      time: doc['time'],
      unread: doc['unread'],
      imageUrl: doc['imageUrl']
    );
  }
}

//// Me_user current
//final User currentUser = User (
//  id :'0',
//  name: 'Current User',
//  ImageUrl: 'assets/images/homme.jpg',
//);
////Users
//// ignore: non_constant_identifier_names
//final User Administration = User(
//  id: '1',
//  name: 'Administration',
//  ImageUrl: 'assets/images/admin.jpg',
//);
//final User Mohamed = User(
//  id: '2',
//  name: 'Mohamed',
//  ImageUrl: 'assets/images/Mohamed.jpg',
//);
//final User Asma = User(
//  id: '3',
//  name: 'Asma',
//  ImageUrl: 'assets/images/Asma.jpg',
//);
//final User Aicha = User(
//  id: '4',
//  name: 'Aicha',
//  ImageUrl: 'assets/images/Aicha.jpeg',
//);
//final User Ahmed = User(
//  id: '4',
//  name: 'Ahmed',
//  ImageUrl: 'assets/images/Ahmed.jpg',
//);
//final User Olfa = User(
//  id: '5',
//  name: 'Olfa',
//  ImageUrl: 'assets/images/Olfa.jpg',
//);
//final User Khadija = User(
//  id: '6',
//  name: 'Khadija',
//  ImageUrl: 'assets/images/Khadija.jpeg',
//);
//// Contacts Favoris
//List <User> favorites = [Administration, Ahmed, Olfa, Khadija, Mohamed, Asma ];
//
//// Example de messagerie
//List <Message> chats = [
//  Message(
//    sender: Administration,
//    time: '14:50',
//    text: 'Salut madame, blablablablablabla',
//    isLiked: false,
//    unread: true,
//  ),
//  Message(
//    sender: Olfa,
//    time: '14:51',
//    text: 'Salut, blablablablablabla',
//    isLiked: false,
//    unread: false,
//  ),
//  Message(
//    sender: Ahmed,
//    time: '14:55',
//    text: 'OK madame, blablablablablabla',
//    isLiked: true,
//    unread: true,
//  ),
//  Message(
//    sender: Aicha,
//    time: '17:55',
//    text: 'Bonjour madame, blablablablablabla',
//    isLiked: true,
//    unread: true,
//  ),
//  Message(
//    sender: Mohamed,
//    time: '11:55',
//    text: 'Bonjour madame, blablablablablabla',
//    isLiked: false,
//    unread: false,
//  ),
//  Message(
//    sender: Asma,
//    time: '10:55',
//    text: 'Bonjour madame, blablablablablabla',
//    isLiked: false,
//    unread: true,
//  ),
//  Message(
//    sender: Khadija,
//    time: '11:05',
//    text: 'Bonjour madame, blablablablablabla',
//    isLiked: false,
//    unread: true,
//  ),
//];
//
//List<Message> messages = [
//  Message(
//    sender: Administration,
//    time: '14:50',
//    text: 'Salut madame, blablablablablabla',
//    isLiked: false,
//    unread: true,
//  ),
//  Message(
//    sender: currentUser,
//    time: '14:55',
//    text: 'Salut Monsieur, blablablablablabla',
//    isLiked: false,
//    unread: true,
//  ),
//  Message(
//    sender: Administration,
//    time: '17:00',
//    text: 'Salut madame, blablablablablabla',
//    isLiked: true,
//    unread: true,
//  ),
//  Message(
//    sender: Administration,
//    time: '14:50',
//    text: 'Salut madame, blablablablablabla',
//    isLiked: true,
//    unread: true,
//  ),
//  Message(
//    sender: currentUser,
//    time: '15.00',
//    text: 'OK Monsieur, blablablablablabla',
//    isLiked: true,
//    unread: true,
//  ),
//  Message(
//    sender: Administration,
//    time: '10:00',
//    text: 'Bonjour Madame, blablablablablabla',
//    isLiked: true,
//    unread: true,
//  ),
//];
