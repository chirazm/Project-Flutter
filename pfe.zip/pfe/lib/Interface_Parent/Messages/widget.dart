import 'package:flutter/material.dart';

Widget appBarMain(BuildContext context) {
  return AppBar(
    title: Image.asset(
      "assets/images/absence.jpg",
      height: 40,
    ),
    elevation: 0.0,
    centerTitle: false,
  );
}

InputDecoration textFieldInputDecoration(String hintText) {
  return InputDecoration(
      hintText: hintText,
      hintStyle: TextStyle(color: Colors.blue),
      focusedBorder:
      UnderlineInputBorder(borderSide: BorderSide(color: Colors.blue)),
      enabledBorder:
      UnderlineInputBorder(borderSide: BorderSide(color: Colors.blue)));
}

TextStyle simpleTextStyle() {
  return TextStyle(color: Colors.blue, fontSize: 16);
}

TextStyle biggerTextStyle() {
  return TextStyle(color: Colors.blue, fontSize: 17);
}