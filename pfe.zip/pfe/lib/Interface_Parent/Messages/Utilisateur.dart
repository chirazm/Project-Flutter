class User {
  final String uid;
  User({this.uid});
}





//import 'package:cloud_firestore/cloud_firestore.dart';
//
//class User {
//  final String id;
//  final String name;
//  final String ImageUrl;
//
//  User({
//    this.id,
//    this.name,
//    this.ImageUrl,
//  });
//  factory User.fromDoc(DocumentSnapshot doc) {
//    return User(
//        id: doc.documentID,
//        name: doc['name'],
//        ImageUrl: doc['ImageUrl'],
//    );
//}}
