//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:pfe/Messages/message_model.dart';
//import 'package:pfe/Messages/chat_screen.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//class ContactsFavoris extends StatefulWidget {
//  @override
//  _ContactsFavorisState createState() => _ContactsFavorisState();
//}
//
//class _ContactsFavorisState extends State<ContactsFavoris> {
////  Icon cusIcon = Icon(Icons.search);
////  Widget cusSearchBar = Text('');
//  Future _data;
//  Future getFavoris() async {
//    var firestore = Firestore.instance;
//    QuerySnapshot qn = await firestore.collection("Contacts Favoris").getDocuments();
//    return qn.documents;
//  }
//  void initState() {
//    super.initState();
//    _data = getFavoris();
//  }
//  @override
//  Widget build(BuildContext context) {
//    return Container(
//                child : SizedBox(height: 120.0,
//                  child: FutureBuilder(
//                  future: _data,
//                  builder: (_, snapshot) {
//                  if (snapshot.connectionState == ConnectionState.waiting) {
//                    return Center(
//                      child: Text(
//                      "Loading ...")
//                      );
//                    } else
//                      return ListView.builder(
//                        scrollDirection: Axis.horizontal,
//                        itemCount: snapshot.data.length,
//                        itemBuilder: (BuildContext context, int index){
//                          return GestureDetector(
//                            onTap: () => Navigator.push
//                              (context,
//                              MaterialPageRoute(
//                                builder: (_) => ChatScreen(
//                                    user: favorites[index]),
//                              ),
//                            ),
//                            child: Padding(
//                              padding:  EdgeInsets.all(10.0),
//                              child: Column (
//                                children: <Widget>[
//                                  CircleAvatar(
//                                    radius: 30.0,
//                                    backgroundImage: NetworkImage(snapshot.data[index].data["image"]),
//                                  ),
//                                  SizedBox(height: 6.0),
//                                  Text(snapshot.data[index].data["name"],
//                                    style: TextStyle(
//                                      color: Colors.blueGrey,
//                                      fontSize: 16.0,
//                                      fontWeight: FontWeight.w600,
//                                    ),
//                                  ),
//                                ],
//                              ),
//                            )
//                          );
//                    }
//                );
//              }),
//              ));
//  }
//}
//
//
////Padding(
////padding: const EdgeInsets.symmetric(horizontal: 20.0),
////child: Row (
////mainAxisAlignment: MainAxisAlignment.spaceBetween,
////children: <Widget>[
////Text('Contacts Favoris',
////style: TextStyle(
////color: Colors.blueGrey,
////fontSize: 18.0,
////fontWeight: FontWeight.bold,
////letterSpacing: 1.0,
////)),
////IconButton(
////icon: cusIcon,
////iconSize: 30.0,
////color: Colors.blueGrey,
////alignment: Alignment(70.0,0.0) ,
////onPressed: () {
////if (this.cusIcon.icon == Icons.search){
////this.cusIcon =Icon(Icons.cancel);
////this.cusSearchBar= TextField(
////
////);
////}
////else{}
////},
////),
////IconButton(
////icon: Icon(
////Icons.more_vert,
////),
////iconSize: 30.0,
////color: Colors.blueGrey,
////onPressed: (){},
////),
////
////],
////),
////),