//
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:pfe/Messages/message_model.dart';
//
//Future<List<Message>> getChatMessages(String senderId, String receiverId) async {
//  List<Message> messages = [];
//  QuerySnapshot messagesSenderQuerySnapshot = await chatsRef
//      .where('sender', isEqualTo: senderId)
//      .where('receiver', isEqualTo: receiverId)
//      .orderBy('timestamp', descending: true)
//      .getDocuments();
//
//  messagesSenderQuerySnapshot.documents.forEach((doc) {
//    print(doc.documentID);
//    messages.add(Message.fromDoc(doc));
//  });
//  QuerySnapshot messagestoQuerySnapshot = await chatsRef
//      .where('sender', isEqualTo: receiverId)
//      .where('receiver', isEqualTo: senderId)
//      .orderBy('timestamp', descending: true)
//      .getDocuments();
//
//  messagestoQuerySnapshot.documents.forEach((doc) {
//    print(doc.documentID);
//    messages.add(Message.fromDoc(doc));
//  });
//
//  Comparator<Message> timestampComparator =
//      (a, b) => b.timestamp.compareTo(a.timestamp);
//  messages.sort(timestampComparator);
//  return messages;
//}
//
//void sendChatMessage(Message message) {
//  chatsRef.add({
//    'sender': message.sender,
//    'receiver': message.receiver,
//    'text': message.text,
//    'imageUrl': message.imageUrl,
//    'isLiked': message.isLiked,
//    'unread': message.unread,
//    'timestamp': Timestamp.fromDate(DateTime.now()),
//  });
//}