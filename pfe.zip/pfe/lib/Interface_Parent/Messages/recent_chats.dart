//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:pfe/Messages/message_model.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:pfe/Messages/chat_screen.dart';
//
//
//class RecentChats extends StatefulWidget {
//  @override
//  _RecentChatsState createState() => _RecentChatsState();
//}
//
//class _RecentChatsState extends State<RecentChats> {
//  Future _data;
//  Future getChatScreen() async {
//    var firestore = Firestore.instance;
//    QuerySnapshot qn = await firestore.collection("chats").getDocuments();
//    return qn.documents;
//  }
//  void initState() {
//    super.initState();
//    _data = getChatScreen();
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    return Expanded(
//      child: Container(
//        decoration: BoxDecoration(
//          color: Theme.of(context).accentColor,
//          borderRadius: BorderRadius.only(
//            topRight: Radius.circular(30.0),
//            topLeft: Radius.circular(30.0),
//          ),
//        ),
//        child: ClipRRect(
//          borderRadius: BorderRadius.only(
//            topLeft: Radius.circular(30.0),
//            topRight: Radius.circular(30.0),
//          ),
//          child: FutureBuilder(
//          future: _data,
//          builder: (_, snapshot) {
//            if (snapshot.connectionState == ConnectionState.waiting) {
//              return Center(
//                  child: Text(
//                      "Loading ...")
//              );
//            } else
//              return (
//                  ListView.builder(
//                      itemCount: snapshot.data.length,
//                      itemBuilder: (BuildContext context, int index) {
//                        final Message chat = chats[index];
//                        return GestureDetector(
//                          onTap: () =>
//                              Navigator.push
//                                (
//                                context,
//                                MaterialPageRoute(
//                                  builder: (_) =>
//                                      ChatScreen(),
//                                ),
//                              ),
//                          child: Container(
//                            margin: EdgeInsets.only(
//                              top: 3.0, bottom: 3.0,),
//                            padding: EdgeInsets.symmetric(
//                                horizontal: 20.0, vertical: 10.0),
//                            decoration: BoxDecoration(
//                              color: chat.unread ? Color(
//                                  0xFFFCE4EC) : Colors.white,
//                              borderRadius: BorderRadius.only(
//                                  topRight: Radius.circular(
//                                      20.0),
//                                  bottomRight: Radius.circular(
//                                      20.0)
//                              ),
//                            ),
//                            child: Row(
//                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                              children: <Widget>[
//                                Row(
//                                  children: <Widget>[
//                                    CircleAvatar(
//                                      radius: 35.0,
//                                      backgroundImage: NetworkImage(
//                                          snapshot.data[index].data["ImageUrl"]),
//                                    ),
//                                    SizedBox(
//                                        width: 12.0
//                                    ),
//                                    Column(
//                                      crossAxisAlignment: CrossAxisAlignment
//                                          .start,
//                                      children: <Widget>[
//                                        Text(
//                                          snapshot.data[index].data["name"],
//                                          style: TextStyle(
//                                              color: Colors.black,
//                                              fontSize: 20.0,
//                                              fontWeight: FontWeight.bold
//                                          ),
//                                        ),
//                                        SizedBox(
//                                            height: 5.0
//                                        ),
//                                        Container(
//                                          width: MediaQuery
//                                              .of(
//                                              context)
//                                              .size
//                                              .width * 0.45,
//                                          child: Text(
//                                            snapshot.data[index].data["Text"],
//                                            style: TextStyle(
//                                                color: Colors.grey,
//                                                fontSize: 15.0,
//                                                fontWeight: FontWeight.w600
//                                            ),
//                                            overflow: TextOverflow.ellipsis,
//                                          ),
//                                        ),
//                                      ],
//                                    )
//                                  ],
//                                ),
//                                Column(
//                                  children: <Widget>[
//                                    Text(
//                                      snapshot.data[index].data["time"],
//                                      style: TextStyle(
//                                          color: Colors.grey,
//                                          fontWeight: FontWeight.bold
//                                      ),),
//                                    SizedBox(
//                                      height: 15.0,),
//                                    chat.unread ? Icon(
//                                      Icons.mail,
//                                      color: Theme
//                                          .of(
//                                          context)
//                                          .primaryColor,
//                                    ) : SizedBox.shrink(
//                                    ),
//
//                                  ],
//                                )
//                              ],
//                            ),
//                          ),
//                        );
//                         },
//              ));
//          }) ,
//      ),
//    ));
//  }
//}
