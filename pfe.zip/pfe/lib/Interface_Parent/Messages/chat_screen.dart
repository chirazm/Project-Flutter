import 'dart:io';
import 'package:pfe/Interface_Parent/Messages/constants.dart';
import 'package:pfe/Interface_Parent/Messages/database.dart';
import 'package:pfe/Interface_Parent/Messages/widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ChatScreen extends StatefulWidget {
  final String ChatScreenRoomId;

  ChatScreen({this.ChatScreenRoomId});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {

  Stream<QuerySnapshot> ChatScreens;
  TextEditingController messageEditingController = new TextEditingController();

  Widget ChatScreenMessages(){
    return StreamBuilder(
      stream: ChatScreens,
      builder: (context, snapshot){
        return snapshot.hasData ?  ListView.builder(
            itemCount: snapshot.data.documents.length,
            itemBuilder: (context, index){
              return MessageTile(
                message: snapshot.data.documents[index].data["message"],
                sendByMe: Constants.myName == snapshot.data.documents[index].data["sendBy"],
              );
            }) : Container();
      },
    );
  }

  addMessage() {
    if (messageEditingController.text.isNotEmpty) {
      Map<String, dynamic> ChatScreenMessageMap = {
        "sendBy": Constants.myName,
        "message": messageEditingController.text,
        'time': DateTime
            .now()
            .millisecondsSinceEpoch,
      };

      DatabaseMethods().addMessage(widget.ChatScreenRoomId, ChatScreenMessageMap);

      setState(() {
        messageEditingController.text = "";
      });
    }
  }

  @override
  void initState() {
    DatabaseMethods().getChats(widget.ChatScreenRoomId).then((val) {
      setState(() {
        ChatScreens = val;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarMain(context),
      body: Container(
        child: Stack(
          children: [
            ChatScreenMessages(),
            Container(alignment: Alignment.bottomCenter,
              width: MediaQuery
                  .of(context)
                  .size
                  .width,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 24),
                color: Color(0x54FFFFFF),
                child: Row(
                  children: [
                    Expanded(
                        child: TextField(
                          controller: messageEditingController,
                          style: simpleTextStyle(),
                          decoration: InputDecoration(
                              hintText: "Message ...",
                              hintStyle: TextStyle(
                                color: Colors.blue,
                                fontSize: 16,
                              ),
                              border: InputBorder.none
                          ),
                        )),
                    SizedBox(width: 16,),
                    GestureDetector(
                      onTap: () {
                        addMessage();
                      },
                      child: Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  colors: [
                                    const Color(0x36FFFFFF),
                                    const Color(0x0FFFFFFF)
                                  ],
                                  begin: FractionalOffset.topLeft,
                                  end: FractionalOffset.bottomRight
                              ),
                              borderRadius: BorderRadius.circular(40)
                          ),
                          padding: EdgeInsets.all(12),
                          child: Icon(Icons.send)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}

class MessageTile extends StatelessWidget {
  final String message;
  final bool sendByMe;

  MessageTile({@required this.message, @required this.sendByMe});


  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          top: 8,
          bottom: 8,
          left: sendByMe ? 0 : 24,
          right: sendByMe ? 24 : 0),
      alignment: sendByMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: sendByMe
            ? EdgeInsets.only(left: 30)
            : EdgeInsets.only(right: 30),
        padding: EdgeInsets.only(
            top: 17, bottom: 17, left: 20, right: 20),
        decoration: BoxDecoration(
            borderRadius: sendByMe ? BorderRadius.only(
                topLeft: Radius.circular(23),
                topRight: Radius.circular(23),
                bottomLeft: Radius.circular(23)
            ) :
            BorderRadius.only(
                topLeft: Radius.circular(23),
                topRight: Radius.circular(23),
                bottomRight: Radius.circular(23)),
            gradient: LinearGradient(
              colors: sendByMe ? [
                const Color(0xff007EF4),
                const Color(0xff2A75BC)
              ]
                  : [
                const Color(0x1AFFFFFF),
                const Color(0x1AFFFFFF)
              ],
            )
        ),
        child: Text(message,
            textAlign: TextAlign.start,
            style: TextStyle(
                color: Colors.blue,
                fontSize: 16,
                fontFamily: 'OverpassRegular',
                fontWeight: FontWeight.w300)),
      ),
    );
  }
}


////
////
////
////
////
//////import 'package:flutter/cupertino.dart';
//////import 'package:flutter/material.dart';
//////import 'package:cloud_firestore/cloud_firestore.dart';
//////import 'package:firebase_auth/firebase_auth.dart';
//////class ChatScreen extends StatefulWidget {
//////  static const String id = "ChatScreen";
//////  final FirebaseUser user;
//////
//////  const ChatScreen({Key key, this.user}) : super(key: key);
//////  @override
//////  _ChatScreenState createState() => _ChatScreenState();
//////}
//////
//////class _ChatScreenState extends State<ChatScreen> {
//////  final FirebaseAuth _auth = FirebaseAuth.instance;
//////  final Firestore _firestore = Firestore.instance;
//////
//////  TextEditingController messageController = TextEditingController();
//////  ScrollController scrollController = ScrollController();
//////
//////  Future<void> callback() async {
//////    if (messageController.text.length > 0) {
//////      await _firestore.collection('Messages').add({
//////        'text': messageController.text,
//////        'from': widget.user.email,
//////        'date': DateTime.now().toIso8601String().toString(),
//////      });
//////      messageController.clear();
//////      scrollController.animateTo(
//////        scrollController.position.maxScrollExtent,
//////        curve: Curves.easeOut,
//////        duration: const Duration(milliseconds: 300),
//////      );
//////    }
//////  }
//////
//////  @override
//////  Widget build(BuildContext context) {
//////    return  SafeArea(
//////        child: Column(
//////          mainAxisAlignment: MainAxisAlignment.spaceBetween,
//////          children: <Widget>[
//////            Expanded(
//////              child: StreamBuilder<QuerySnapshot>(
//////                stream: _firestore
//////                    .collection('Messages')
//////                    .orderBy('date')
//////                    .snapshots(),
//////                builder: (context, snapshot) {
//////                  if (!snapshot.hasData)
//////                    return Center(
//////                      child: CircularProgressIndicator(),
//////                    );
//////
//////                  List<DocumentSnapshot> docs = snapshot.data.documents;
//////
//////                  List<Widget> messages = docs
//////                      .map((doc) => Message(
//////                    from: doc.data['from'],
//////                    text: doc.data['text'],
//////                    me: widget.user.email == doc.data['from'],
//////                  ))
//////                      .toList();
//////
//////                  return ListView(
//////                    controller: scrollController,
//////                    children: <Widget>[
//////                      ...messages,
//////                    ],
//////                  );
//////                },
//////              ),
//////            ),
//////            Container(
//////              child: Row(
//////                children: <Widget>[
//////                  Expanded(
//////                    child: TextField(
//////                      onSubmitted: (value) => callback(),
//////                      decoration: InputDecoration(
//////                        hintText: "Enter a Message...",
//////                        border: const OutlineInputBorder(),
//////                      ),
//////                      controller: messageController,
//////                    ),
//////                  ),
//////                  SendButton(
//////                    text: "Send",
//////                    callback: callback,
//////                  )
//////                ],
//////              ),
//////            ),
//////          ],
//////        ),
//////    );
//////  }
//////}
//////
//////class SendButton extends StatelessWidget {
//////  final String text;
//////  final VoidCallback callback;
//////
//////  const SendButton({Key key, this.text, this.callback}) : super(key: key);
//////  @override
//////  Widget build(BuildContext context) {
//////    return FlatButton(
//////      color: Colors.orange,
//////      onPressed: callback,
//////      child: Text(text),
//////    );
//////  }
//////}
//////
//////class Message extends StatelessWidget {
//////  final String from;
//////  final String text;
//////
//////  final bool me;
//////
//////  const Message({Key key, this.from, this.text, this.me}) : super(key: key);
//////
//////  @override
//////  Widget build(BuildContext context) {
//////    return Container(
//////      child: Column(
//////        crossAxisAlignment:
//////        me ? CrossAxisAlignment.end : CrossAxisAlignment.start,
//////        children: <Widget>[
//////          Text(
//////from         ),
//////          Material(
//////            color: me ? Colors.teal : Colors.blue,
//////            borderRadius: BorderRadius.circular(10.0),
//////            elevation: 6.0,
//////            child: Container(
//////              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 15.0),
//////              child: Text(
//////                text,
//////              ),
//////            ),
//////          )
//////        ],
//////      ),
//////    );
//////  }
//////}




////////
////
//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:intl/intl.dart';
//import 'package:pfe/Evenements/event%20_firestore.dart';
//import 'package:pfe/Messages/message_model.dart';
//import 'Utilisateur.dart';
//class ChatScreen extends StatefulWidget {
//  final User user;
//  ChatScreen ({this.user});
//  @override
//  _ChatScreenState createState() => _ChatScreenState();
//}
////42.36
//class _ChatScreenState extends State<ChatScreen> {
//   final DateFormat timeFormat = DateFormat('E, h:m a');
//   List<Message> _messages =[];
//   @override
//    void initState(){
//     super.initState();
//     _setupMessages();
//   }
//   _setupMessages() async {
//     List<Message> messages = await FirebaseService.getChatMessages(
//         widget.currentUserId, widget.toUserId);
//     setState(() {
//       _messages = messages;
//     });
//   }
//   _buildMessage (Message message, bool isMe){
//    return Container(
//        margin: isMe
//            ? EdgeInsets.only(
//            top: 8.0,
//            bottom: 8.0,
//            left: 80.0
//        ): EdgeInsets.only(
//          top: 8.0,
//          bottom: 8.0,
//          right: 80.0,
//        ),
//        padding: EdgeInsets.symmetric(horizontal: 25.0,vertical: 15.0),
//        decoration : BoxDecoration(
//            color: isMe ? Color(0xFFFCE4EC) : Color(0xFFF8BBD0),
//            borderRadius: isMe
//                ? BorderRadius.only(
//                topLeft: Radius.circular(15.0),
//                bottomLeft: Radius.circular(15.0)
//            ): BorderRadius.only(
//                topRight: Radius.circular(15.0),
//                bottomRight: Radius.circular(15.0)
//            )
//        ),
//        child: Column(
//          crossAxisAlignment: CrossAxisAlignment.start,
//          children: <Widget>[
//            Text(message.time,
//              style: TextStyle(
//                color: Colors.blueGrey,
//                fontSize: 14.0,
//                fontWeight: FontWeight.w600,
//              ),
//            ),
//            SizedBox(height: 8.0,),
//            Text(
//              message.text,
//              style: TextStyle(
//                color: Colors.black,
//                fontSize: 16.0,
//                fontWeight: FontWeight.w600,
//              ),
//            )
//          ],
//        )
//    );
//  }
//  _buildMessageComposer(){
//    return Container(
//      padding: EdgeInsets.symmetric(horizontal: 8.0),
//      height: 70.0,
//      color: Colors.white,
//      child: Row(
//        children: <Widget>[
//          IconButton(
//            icon: Icon(Icons.photo),
//            iconSize: 25.0,
//            color: Theme.of(context).primaryColor,
//            onPressed: () {},
//          ),
//          Expanded(
//            child: TextField(
//              textCapitalization: TextCapitalization.sentences,
//              onChanged: (value ) {},
//              decoration: InputDecoration(
//                  hintText: 'Rédiger un message...'
//              ),
//            ),
//          ),
//          IconButton(
//            icon: Icon(Icons.send),
//            iconSize: 25.0,
//            color: Theme.of(context).primaryColor,
//            onPressed: (){},
//          ),
//        ],
//      ),
//    );
//  }
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      backgroundColor: Theme.of(context).primaryColor,
//      appBar: AppBar(
//        title: Text(
//          widget.user.name,
//          style: TextStyle(
//            fontSize: 22.0,
//            fontWeight: FontWeight.bold,
//          ),
//        ),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(Icons.more_vert),
//            iconSize: 30.0,
//            color: Colors.white,
//            onPressed: () {},
//          )
//        ],
//      ),
//      body: Column(
//        children: <Widget>[
//          Expanded(
//            child: Container(
//              decoration: BoxDecoration(
//                  color: Colors.white,
//                  borderRadius: BorderRadius.only(
//                    topLeft: Radius.circular(30.0),
//                    topRight: Radius.circular(30.0),
//                  )
//              ),
//              child: ClipRRect(
//                  borderRadius: BorderRadius.only(
//                    topLeft: Radius.circular(30.0),
//                    topRight: Radius.circular(30.0),
//                  ),
//                  child: ListView.builder(
//                      scrollDirection: Axis.vertical,
//                      //reverse: true,
//                      padding: EdgeInsets.only(top: 15.0),
//                      itemCount: messages.length,
//                      itemBuilder: (BuildContext context, int index){
//                        final Message message = messages[index];
//                        final bool isMe=message.sender.id == currentUser.id;
//                        return _buildMessage(message,isMe);
//                      }
//                  )
//              ),
//            ),
//          ),
//          _buildMessageComposer(),
//        ],
//      ),
//    );
//  }
//}
