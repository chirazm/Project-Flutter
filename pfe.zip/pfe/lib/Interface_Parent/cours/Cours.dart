import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import'package:cloud_firestore/cloud_firestore.dart';

class Cours extends StatefulWidget {
  @override
  _CoursState createState() => new _CoursState();
}
class _CoursState extends State<Cours> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListPage(),
    );
  }
}

class ListPage extends StatefulWidget {
  @override
  _ListPageState createState() => new _ListPageState();
}
class _ListPageState extends State<ListPage> {
  Future _data;
  Future getCours() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection("Cours").getDocuments(
    );
    return qn.documents;
  }
  navigateToDetail(DocumentSnapshot post){
    Navigator.push(context, MaterialPageRoute(builder: (context) => DetailPage(post: post,)));
  }
@override
  void initState() {
    super.initState();
    _data = getCours();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
        child: FutureBuilder(
            future: _data,
            builder: (_, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(
                        child:  Text("Loading ...")
                      );
                    } else return ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (_, index) {{
                      return Column(
                        children: <Widget>[
                          SizedBox(height: 20,),
                          ListTile(
                            subtitle: Text(snapshot.data[index].data["Prof"],),
                            leading: Icon(
                              Icons.description,
                              color: Colors.purple,
                            ),
                            title: Text(
                              snapshot.data[index].data["Titre"],
                              style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                            trailing: Text(
                              snapshot.data[index].data["Date"],

                            ),
                            onTap: () => navigateToDetail(snapshot.data[index]) ,

                          ),
                          Divider(
                            color: Colors.black45,
                            indent: 17,
                          )
                        ],
                      );
                  }
                  }
                  );
            }
        ));
  }
}

class DetailPage extends StatefulWidget {
  final DocumentSnapshot post;
  DetailPage({this.post});
  @override
  _DetailPageState createState() => new _DetailPageState();
}
class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.post.data["Titre"]),
      ),
      body: Container(height: 700,
width: 700,
//            margin: EdgeInsets.only(left: 0,right: 10,top: 30),
                child :Column(
                    children :[Image.network(widget.post.data["cours image"], ),
               ] )
//            leading: Image.network(widget.post.data["cours image"],

//            subtitle: (Text(widget.post.data["Contenu"])

    )

      );
  }
}