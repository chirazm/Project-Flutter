
import 'package:pfe/Interface_Parent/services/user.dart';

class Message {
  final User sender;
  final String time; // Would usually be type DateTime or Firebase Timestamp in production apps
  final String text;
  final bool isLiked;
  final bool unread;

  Message({
    this.sender,
    this.time,
    this.text,
    this.isLiked,
    this.unread,
  });
}
final User currentUser = User(
  id: '0',
  name: 'Current User',
  profileImageUrl: 'assets/images/greg.jpg',
);
final User sumith = User(
  id: '1',
  name: 'sumith',
  profileImageUrl: 'assets/images/greg.jpg',
);
final User martin = User(
  id: '2',
  name: 'martin',
  profileImageUrl: 'assets/images/james.jpg',
);
final User laura = User(
  id: '3',
  name: 'laura',
  profileImageUrl: 'assets/images/john.jpg',
);
final User bilal = User(
  id: '4',
  name: 'bilal',
  profileImageUrl: 'assets/images/olivia.jpg',
);
final User sam = User(
  id: '5',
  name: 'Sam',
  profileImageUrl: 'assets/images/sam.jpg',
);
final User sophia = User(
  id: '6',
  name: 'Sophia',
  profileImageUrl: 'assets/images/sophia.jpg',
);
final User steven = User(
  id: '7',
  name: 'Steven',
  profileImageUrl: 'assets/images/steven.jpg',
);