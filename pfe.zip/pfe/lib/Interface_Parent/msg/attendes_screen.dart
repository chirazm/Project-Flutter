import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_helpers/firebase_helpers.dart';
import 'package:pfe/Interface_Parent/msg/all_attendees.dart';
import 'package:pfe/Interface_Parent/msg/user_data.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import 'package:pfe/Interface_Parent/msg/user.dart';
import 'package:pfe/Interface_Parent/msg/database_service.dart';



class AttendeesScreen extends StatefulWidget {
  static final String id='attendees_screen';
  @override
  _AttendeesScreenState createState() => _AttendeesScreenState();
}

class _AttendeesScreenState extends State<AttendeesScreen> {
  List <User> _users = [];
  @override
  void initState () {
    super.initState();
    _setupAttendees();
  }
  _setupAttendees()async{
    String currentUserId = Provider.of<UserData>(context, listen: false).currentUserId;
    List<User> users = await Provider.of<DataBaseService>(context, listen: false)
        .getAllUsers(currentUserId);
    if(mounted){
      setState(() {
        _users = users;
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.purple,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular((30.0)),
                  topRight: Radius.circular(30.0)
                )
              ),
              child: Column(
                children: <Widget>[
                  AllAttendees (users: _users),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
