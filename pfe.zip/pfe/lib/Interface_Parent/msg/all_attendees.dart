import 'package:flutter/material.dart';
import 'package:pfe/Interface_Parent/msg/user.dart';
import 'package:pfe/Interface_Parent/msg/screen_chat.dart';
import 'package:cached_network_image/cached_network_image.dart';

class AllAttendees extends StatelessWidget {
  final List<User> users;

  const AllAttendees({Key key, this.users}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: Container(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Padding(
                padding: const EdgeInsets.all(8),
                child: ListView.builder(
                    itemCount: users.length,
                    itemBuilder: (BuildContext context, int index) {
                      final User user = users[index];
                      return GestureDetector(
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ChatScreen(),
                            )),
                        child: Container(
                          margin:
                              EdgeInsets.only(top: 5.0, bottom: 50, right: 5.0),
                          padding: EdgeInsets.symmetric(
                              horizontal: 10.0, vertical: 10.0),
                          decoration: BoxDecoration(
                              color: Colors.yellowAccent,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  CircleAvatar(
                                    radius: 35.0,
                                    backgroundImage:
                                        user.profileImageUrl.isEmpty
                                            ? AssetImage(
                                                'assets/images/absence.jpg')
                                            : CachedNetworkImageProvider(
                                                user.profileImageUrl),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        user.name,
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontSize: 15,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5.0,
                                      ),
                                    ],
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      );
                    }))));
  }
}
