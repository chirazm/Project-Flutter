import 'package:flutter/cupertino.dart';

class UserData extends ChangeNotifier {
  String currentUserId;
}