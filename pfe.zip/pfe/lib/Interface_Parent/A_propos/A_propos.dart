import 'package:flutter/material.dart';

class AboutUs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        elevation: 0,
        brightness: Brightness.light,
        backgroundColor: Colors.grey[100],
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back,
            size: 28,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                new Column(
                  children: <Widget>[
                    SizedBox(
                      height: 28,
                    ),
                    Text(
                      "À quoi sert O'School à l’école ?",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 22.0),
                    ),
                    Container(
                      height: 150.0,
                      width: 220.0,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('assets/images/oschoo.png'),
                          fit: BoxFit.contain,
                        ),
                        shape: BoxShape.rectangle,
                      ),
                    )
                  ],
                ),
                Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: new Container(
                      decoration: new BoxDecoration(
                        color: Colors.grey[400],
                        border: Border.all(
                          color: Colors.grey,
                          //                   <--- border color
                          width: 3,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(20.0)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple[600],
                            blurRadius: 20.0,
                            offset: const Offset(10.0, 10.0),
                          ),
                        ],
                      ),
                      margin:
                          EdgeInsets.only(left: 35.0, right: 35.0, bottom: 200),
                      padding: EdgeInsets.only(left: 15.0, right: 15.0),
                      child: new Text(
                        "« O'School nous permet de tisser des liens."
                        " C'est un système de gestion d’établissements scolaires complets. "
                        "Il constitue le trait d’union entre la direction de l’établissement, "
                        "le cadre d’enseignement, les parents et les élèves ",
                        style: TextStyle(
                          fontSize: 16,
                          height: 2,
                        ),
                      ),
                    ))
              ])),
    );
  }
}
