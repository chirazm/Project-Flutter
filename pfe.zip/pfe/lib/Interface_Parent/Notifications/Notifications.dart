import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class Notifications extends StatefulWidget {
  @override
  _NotificationsState createState() => new _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListPage(),
    );
  }
}

class ListPage extends StatefulWidget {
  @override
  _ListPageState createState() => new _ListPageState();
}

class _ListPageState extends State<ListPage> {
  Future _data;

  Future getPosts() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn =
        await firestore.collection("Notifications").getDocuments();
    return qn.documents;
  }

  navigateToDetail(DocumentSnapshot post) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => DetailPage(
                  post: post,
                )));
  }

  @override
  void initState() {
    super.initState();
    _data = getPosts();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        child: FutureBuilder(
            future: _data,
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: Text("Loading ..."));
              } else
                return ListView.builder(
                    itemCount: snapshot.data.length,
                    itemBuilder: (_, index) {
                      {
                        return Column(
                          children: <Widget>[
//                    if (snapshot.data[index].data["Lu"] == true)
//                    {
//                      return color: Colors.white,
//                    } else  Color(0xFFFCE4EC),
                            SizedBox(
                              height: 30,
                            ),
                            ListTile(
                              leading: CircleAvatar(
                                  radius: 32,
                                  backgroundImage: NetworkImage(
                                    snapshot.data[index].data["image"],
                                  )),
                              title: Text(
                                snapshot.data[index].data["Nom"],
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                              trailing: Text(
                                snapshot.data[index].data["Date"],
                              ),
                              onTap: () =>
                                  navigateToDetail(snapshot.data[index]),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Divider(
                              color: Colors.blueGrey,
                              indent: 17,
                            )
                          ],
                        );
                      }
                    });
            }));
  }
}

class DetailPage extends StatefulWidget {
  final DocumentSnapshot post;

  DetailPage({this.post});

  @override
  _DetailPageState createState() => new _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(widget.post.data["Nom"]),
        ),
        body: Stack(
          children: [
            Container(
                padding: EdgeInsets.only(left: 30, right: 30, top: 30),
                child: Text(
                  widget.post.data["Texte"],
                  style: TextStyle(
                    height: 2,
                    fontSize: 18.0,
                  ),
                ))
          ],
        ));
  }
}
