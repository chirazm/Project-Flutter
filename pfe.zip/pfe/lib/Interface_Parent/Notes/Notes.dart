import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Note extends StatefulWidget {
  @override
  _NoteState createState()=> _NoteState();
}
class  _NoteState extends State<Note>{
  Future getNotes() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection("Notes").getDocuments(
    );
    return qn.documents;
  }
  @override
  void initState() {
    super.initState();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[350],
        title: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Image.asset(
                'assets/images/oschoo.png',
                fit: BoxFit.contain,
                height: 70,
                width: 90,
              ),
            ]
        ),
      ),

      body: Container(
        child:  ListView(
            padding: EdgeInsets.only(top: 30),
            children: <Widget>[
              Column(
                children: <Widget>[
                  SizedBox(height: 20,),
                  Center(
                    child: Text(
                        "1er trimestre",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 28.0,
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                            fontStyle: FontStyle.italic
                        )
                    ),
                  )
                ],
              ),

                Container(
                    child: SizedBox(
                      height: 1500,
                        child: FutureBuilder(
                          future: getNotes(),
                          builder: (_, snapshot) {
                          if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(
                            child: Text(
                            "Loading ...")
                            );
                          } else
                          return
                              GridView(
                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount:  1,
                                  ),
                                  children: [
                              ListView.builder(
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (_, index) {
                                return
//                                  Column(
//                                    children: <Widget>[
                                      Container(
                                        child:
                                          Container(
                                              margin: EdgeInsets.only(
                                                  top: 30,
                                                  left: 30,
                                                  bottom: 12),
                                              padding: EdgeInsets.only(
                                                top: 12, left: 12,),
                                              height: 140,
                                              width: 160,
                                              decoration: BoxDecoration(
                                                color: Colors.red
                                                    .withOpacity(
                                                    0.1),
                                                borderRadius: BorderRadius
                                                    .circular(
                                                    20),
                                              ),
                                              child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment
                                                      .center,
                                                  children: [
                                                    Row(
                                                      children: <Widget>[
                                                        Container(
                                                          height: 6,
                                                          width: 6,
                                                          decoration: BoxDecoration(
                                                            color: Colors
                                                                .red
                                                                .withOpacity(
                                                                0.1),
                                                            borderRadius: BorderRadius
                                                                .circular(
                                                                3),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 5,),
                                                        Text(
                                                          snapshot
                                                              .data[index]
                                                              .data["Title" ??
                                                              'default value'],
                                                          style: TextStyle(
                                                              fontSize: 18,
                                                              color: Colors
                                                                  .black,
                                                              fontWeight: FontWeight
                                                                  .bold),
                                                        ),
                                                      ],
                                                    ),

                                                    SizedBox(
                                                      height: 10,),
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 20,),
                                                        Icon(
                                                          Icons
                                                              .border_color,
                                                          size: 18,),
                                                        SizedBox(
                                                          width: 6,),
                                                        Text(
                                                          snapshot
                                                              .data[index]
                                                              .data["Note" ??
                                                              'default value'],
                                                          style: TextStyle(
                                                              fontSize: 16,
                                                              fontWeight: FontWeight
                                                                  .bold),
                                                        ),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      height: 10,),
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 20,),
                                                        Icon(
                                                          Icons
                                                              .description,
                                                          size: 20,),
                                                        SizedBox(
                                                          width: 6,),
                                                        Container(
                                                          width: 80,
                                                          child: Text(
                                                            snapshot
                                                                .data[index]
                                                                .data["TypeExam" ??
                                                                'default value'],
                                                            style: TextStyle(
                                                              fontSize: 16,
                                                              fontWeight: FontWeight
                                                                  .bold,
                                                            ),
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    SizedBox(
                                                        height: 10),
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 20,),
                                                        Icon(
                                                          Icons
                                                              .access_time,
                                                          size: 20,),
                                                        SizedBox(
                                                          width: 6,),
                                                        Container(
                                                          width: 100,
                                                          child: Text(
                                                            snapshot
                                                                .data[index]
                                                                .data["Date" ??
                                                                'default value'],
                                                            style: TextStyle(
                                                              fontSize: 16,
                                                              fontWeight: FontWeight
                                                                  .bold,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    )

                                                  ])
                                          ),

                                );
                              }


                                      //                    Column(
                                      //                      children: [
                                      //                       Row(
                                      //                          children: <Widget>[
                                      //                          buildTaskItem("Edu.Cvile","15.00", "Evaluation", Colors.green,"12-9-2019"),
                                      //                          buildTaskItem("Mathématiques","17.75", "Examen", Colors.red,"7-12-2019"),
                                      //
                                      //                          Row(
                                      //                            children: <Widget>[
                                      //                              buildTaskItem("Anglais","13.50", "Examen", Colors.purple,"9-12-2019"),
                                      //                              buildTaskItem("Edu.Islamique","18.00", "Oral", Colors.indigo,"1-12-2019"),
                                      //                            ],
                                      //                          ),
                                      //                          SizedBox(height: 12,),
                                      //                          Column(
                                      //                            children: <Widget>[
                                      //                              SizedBox(height: 20,),
                                      //                              Center(
                                      //                                child: Text(
                                      //                                  "2ème trimestre",
                                      //                                  textAlign: TextAlign.center,
                                      //                                  style: TextStyle(
                                      //                                      color: Colors.black,
                                      //                                      fontSize: 28.0,
                                      //                                      fontWeight: FontWeight.bold,
                                      //                                      decoration: TextDecoration.underline,
                                      //                                      fontStyle: FontStyle.italic
                                      //                                  )
                                      //                      ),
                                      //                  )
                                      //                ],
                                      //              ),
                                      //              Row(
                                      //                children: <Widget>[
                                      //                  buildTaskItem("Français","13.50", "Evaluation", Colors.yellowAccent,"5-2-2020"),
                                      //                  buildTaskItem("Edu.Islamique","20.00", "Examen", Colors.indigo,"16-1-2020"),
                                      //                ],
                                      //              ),
                                      //              Row(
                                      //                children: <Widget>[
                                      //                  buildTaskItem("Edu.Cvile","15.00", "Examen", Colors.green,"5-1-2020"),
                                      //                  buildTaskItem("Sciences","20.00", "Examen", Colors.orange,"14-3-2020"),
                                      //                ],
                                      //              ),
                                      //              SizedBox(height: 12,),
                                      //              Column(
                                      //                children: <Widget>[
                                      //                  SizedBox(height: 20,),
                                      //                  Center(
                                      //                      child: Text(
                                      //                          "3ème trimestre",
                                      //                          textAlign: TextAlign.center,
                                      //                          style: TextStyle(
                                      //                              color: Colors.black,
                                      //                              fontSize: 28.0,
                                      //                              fontWeight: FontWeight.bold,
                                      //                              decoration: TextDecoration.underline,
                                      //                              fontStyle: FontStyle.italic
                                      //                          )
                                      //                      ),
                                      //                  )
                                      //                ],
                                      //              ),
                                      //              Row(
                                      //                children: <Widget>[
                                      //                  buildTaskItem("Sciences","18.50", "Examen", Colors.orange,"15-5-2020"),
                                      //                  buildTaskItem("Arabe","20.00", "Examen", Colors.grey,"18-5-2020"),
                                      //                ],
                                      //              ),
                                      //              Row(
                                      //                children: <Widget>[
                                      //                  buildTaskItem("Mathématiques","15.00", "Examen", Colors.red,"01-6-2020"),
                                      //                ],
                                      //              ),
                                      //
                                      //            ]),

                            ),
    ]);}
                          )))
    ])));


}
  }


//Container buildTaskItem(String matTitle, String numNotes, String nameExam, Color color, String Date) {
//  return Container(
//    margin: EdgeInsets.only(top:20,left: 30,bottom: 12),
//    padding: EdgeInsets.only(top: 12,left: 12),
//    height: 140,
//    width: 160,
//    decoration: BoxDecoration(
//      color: color.withOpacity(0.1),
//      borderRadius: BorderRadius.circular(20),
//    ),
//    child: Column(
//      crossAxisAlignment: CrossAxisAlignment.center,
//      children: [
//        Row(
//          children: <Widget>[
//            Container(
//              height: 6,
//              width: 6,
//              decoration: BoxDecoration(
//                color: color,
//                borderRadius: BorderRadius.circular(3),
//              ),
//            ),
//            SizedBox(width: 5,),
//            Text(
//              matTitle,
//              style: TextStyle(
//                  fontSize: 18,
//                  color: Colors.black,
//                  fontWeight: FontWeight.bold),
//            ),
//          ],
//        ),
//
//        SizedBox(height: 10,),
//        Row(
//          children: [
//            SizedBox(width: 20,),
//            Icon(Icons.border_color,
//              size: 18,),
//            SizedBox(width: 6,),
//            Text(
//              "$numNotes",
//              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//            ),
//          ],
//        ),
//        SizedBox(height: 10,),
//        Row(
//          children: [
//            SizedBox(width: 20,),
//            Icon(Icons.description,
//              size: 20,),
//            SizedBox(width: 6,),
//            Container(
//              width: 80,
//              child: Text(
//                nameExam,
//                style: TextStyle(
//                  fontSize: 16,
//                  fontWeight: FontWeight.bold,
//                ),
//              ),
//            )],
//        ),
//        SizedBox(height: 10),
//        Row(
//            children: [
//              SizedBox(width: 20,),
//              Icon(Icons.access_time,
//                size: 20,),
//              SizedBox(width: 6,),
//              Container(
//                width: 80,
//                child: Text(
//                  Date,
//                  style: TextStyle(
//                    fontSize: 16,
//                    fontWeight: FontWeight.bold,
//                  ),
//                ),
//              ),
//            ]),
//      ],
//    ),
//  );

//}



//                    Column(
//                      children: [
//                       Row(
//                          children: <Widget>[
//                          buildTaskItem("Edu.Cvile","15.00", "Evaluation", Colors.green,"12-9-2019"),
//                          buildTaskItem("Mathématiques","17.75", "Examen", Colors.red,"7-12-2019"),
//
//                          Row(
//                            children: <Widget>[
//                              buildTaskItem("Anglais","13.50", "Examen", Colors.purple,"9-12-2019"),
//                              buildTaskItem("Edu.Islamique","18.00", "Oral", Colors.indigo,"1-12-2019"),
//                            ],
//                          ),
//                          SizedBox(height: 12,),
//                          Column(
//                            children: <Widget>[
//                              SizedBox(height: 20,),
//                              Center(
//                                child: Text(
//                                  "2ème trimestre",
//                                  textAlign: TextAlign.center,
//                                  style: TextStyle(
//                                      color: Colors.black,
//                                      fontSize: 28.0,
//                                      fontWeight: FontWeight.bold,
//                                      decoration: TextDecoration.underline,
//                                      fontStyle: FontStyle.italic
//                                  )
//                      ),
//                  )
//                ],
//              ),
//              Row(
//                children: <Widget>[
//                  buildTaskItem("Français","13.50", "Evaluation", Colors.yellowAccent,"5-2-2020"),
//                  buildTaskItem("Edu.Islamique","20.00", "Examen", Colors.indigo,"16-1-2020"),
//                ],
//              ),
//              Row(
//                children: <Widget>[
//                  buildTaskItem("Edu.Cvile","15.00", "Examen", Colors.green,"5-1-2020"),
//                  buildTaskItem("Sciences","20.00", "Examen", Colors.orange,"14-3-2020"),
//                ],
//              ),
//              SizedBox(height: 12,),
//              Column(
//                children: <Widget>[
//                  SizedBox(height: 20,),
//                  Center(
//                      child: Text(
//                          "3ème trimestre",
//                          textAlign: TextAlign.center,
//                          style: TextStyle(
//                              color: Colors.black,
//                              fontSize: 28.0,
//                              fontWeight: FontWeight.bold,
//                              decoration: TextDecoration.underline,
//                              fontStyle: FontStyle.italic
//                          )
//                      ),
//                  )
//                ],
//              ),
//              Row(
//                children: <Widget>[
//                  buildTaskItem("Sciences","18.50", "Examen", Colors.orange,"15-5-2020"),
//                  buildTaskItem("Arabe","20.00", "Examen", Colors.grey,"18-5-2020"),
//                ],
//              ),
//              Row(
//                children: <Widget>[
//                  buildTaskItem("Mathématiques","15.00", "Examen", Colors.red,"01-6-2020"),
//                ],
//              ),
//
//            ]),