//import 'package:shared_preferences/shared_preferences.dart';
//
//Future<String> setProfileImageURI(String ImageUri ) async {
//  SharedPreferences _prefs = await SharedPreferences.getInstance ( );
//  _prefs.setString ( "ImageUri" , ImageUri);
//}
//Future<String> getProfileImageUri(
//    ) async {
//  SharedPreferences _prefs = await SharedPreferences.getInstance ( );
//  return _prefs.getString ( "ImageUri" );
//}