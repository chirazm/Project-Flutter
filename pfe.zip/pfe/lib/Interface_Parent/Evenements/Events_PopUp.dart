//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//
//class Event_PopUp extends StatelessWidget {
//  final String title, description;
//  final Image image;
//  final BuildContext context;
//  final Future PopUp;
//
//  Event_PopUp({
//    this.title,
//    this.description,
//    this.context,
//    this.image,
//    this.PopUp,
//  });
//  factory Event_PopUp.fromMap(Map data) {
//    return Event_PopUp(
//      title: data['title'],
//      description: data['description'],
//      image: data['image'],
//    );
//  }
//  factory Event_PopUp.fromDS(String id, Map<String,dynamic> data) {
//    return Event_PopUp(
//      title: data['title'],
//      description: data['description'],
//      image: data['image'].toDate(),
//    );
//  }
//  @override
//  Widget build(BuildContext context) {
//    return AlertDialog(
//      backgroundColor: Colors.transparent,
//      content: Builder(
//        builder: (context) {
//          var height = MediaQuery.of(context).size.height;
//          var width = MediaQuery.of(context).size.width;
//          return Container(
//            height: height - height/3 ,
//            width: width ,
//            child: dialogContent(context),
//          );
//        },
//      ),
//    );
//  }
//  // ignore: non_constant_identifier_names
//  Widget EventDetails (BuildContext _context){
//    return SingleChildScrollView(
//      child: Container(
//        child: Column(
//          children: <Widget>[
//            Row(
//              children: <Widget>[
//                SizedBox(width: 20,),
//                Expanded(
//                  child: Text( 'Compétition musicale',
//                    style: TextStyle(
//                        height: 2,
//                        fontSize: 20,
//                        color: Colors.amber[700],
//                        fontWeight: FontWeight.bold),),),
//              ],
//            ),
//            SizedBox(height: 20,),
//            Row(
//              children: <Widget>[
//                Expanded(
//                  child:
//                  new ListTile (
//                    title:  new Text (
//                        "Le 1 Juin à 18:00",
//                        style: TextStyle(
//                            fontSize: 16,
//                            fontWeight: FontWeight.bold)),
//                    leading: new Icon (
//                      Icons.access_time,
//                      color: Colors.black,),
//                  ),
//                )],
//            ),
//            Row(
//              children: <Widget>[
//                Expanded(
//                  child: new ListTile (
//                    title:  new Text (
//                        "Centre culturel Scolaire",
//                        style: TextStyle(
//                            fontSize: 16,
//                            fontWeight: FontWeight.bold)),
//                    leading: new Icon (
//                      Icons.location_on,
//                      color: Colors.black,),
//                  ),
//                ),
//              ],
//            ),
//            Row(
//              children: <Widget>[
//                Expanded(
//                  child: new ListTile (
//                    title:  new Text (
//                        "10 Dinars",
//                        style: TextStyle(
//                            fontSize: 16,
//                            fontWeight: FontWeight.bold)),
//                    leading: new Icon (
//                      Icons.monetization_on,
//                      color: Colors.black,),
//                  ),
//                ),
//              ],
//            ),
//            new Divider(
//              color: Colors.black,
//              indent: 5,
//            ),
//            SizedBox(height: 10.0),
//            Row(
//              children: <Widget>[
//                Expanded(
//                  child: Text(
//                    'Description : ',
//                    style: TextStyle(
//                      color: Colors.purple,
//                      fontSize: 18.0,
//                      fontWeight: FontWeight.bold,
//                    ),
//                  ),
//                ),
//              ],
//            ),
//            SizedBox(height: 10.0),
//            Row(
//              children: <Widget>[
//                Expanded(
//                  child: Text(
//                    'Cette compétition se déroule   ...........................',
//                    style: TextStyle(
//                      fontSize: 16.0,
//                      height: 2,
//                    ),
//                  ),
//                ),
//              ],
//            ),
//          ],
//        ),
//      ),
//    );
//  }
//  dialogContent(BuildContext context) {
//    Widget cardPart = Container(
//      padding: EdgeInsets.only(
//        top: 70 ,
//        bottom: 50,
//        left: 20,
//        right: 20,
//      ),
//      margin: EdgeInsets.only(top: 40),
//      decoration: new BoxDecoration(
//        border: Border.all(
//            color: Colors.amber[700],
//            width: 2
//        ),
//        color: Colors.white,
//        borderRadius: BorderRadius.circular(30),
//      ),
//      child: EventDetails(context),
//    );
//
//    Widget imagePart = Positioned(
//      left: 20,
//      right: 20,
//      child: CircleAvatar(
//        child: Text(
//          title,
//          textAlign: TextAlign.center,
//          style: TextStyle(
//            fontSize: 20.0,
//            color: Colors.white,
//            fontWeight: FontWeight.bold,
//          ),
//        ),
//        backgroundColor: Colors.deepPurpleAccent[100],
//        radius: 50,
//      ),
//    );
//    return Stack(
//      children: <Widget>[
//        cardPart,
//        imagePart,
//        Positioned.fill(
//            child: Align(
//                alignment: Alignment.topRight,
//                child: close(context)
//            )
//        )
//      ],
//    );
//  }
//  Widget  close( BuildContext _context) {
//    return MaterialButton(
//      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(100)),
//      splashColor: Colors.transparent,
//      hoverColor: Colors.transparent,
//      minWidth: 30,
//      height: 30,
//      child: Container(
//        padding: EdgeInsets.only(top: 5,),
//        child: Icon(
//            Icons.cancel,
//            color: Colors.black,
//            size: 30),
//      ),
//      onPressed: Navigator.of(_context).pop,
//    );
//  }
//
//}
//
//
//
//
