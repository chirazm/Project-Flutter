import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:folding_cell/folding_cell.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Evenements extends StatelessWidget {
//  @override
//  _EvenementsState createState() => new _EvenementsState();
//}
//class _EvenementsState extends State<Evenements> {
  final _foldingCellKey = GlobalKey<SimpleFoldingCellState>();

  Future getEvents() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection("Evenements").getDocuments();
    return qn.documents;
  }

//  @override
//  void initState() {
//    super.initState(
//    );
//  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xffdfd4f4),
      child: ListView(
        shrinkWrap: false,
        scrollDirection: Axis.vertical,
        children: [
          Container(
            child: SimpleFoldingCell(
                key: _foldingCellKey,
                frontWidget: FrontWidget(),
                innerTopWidget: InnerTopWidget(),
                innerBottomWidget: InnerBottomWidget(),
                cellSize: Size(MediaQuery.of(context).size.width, 200),
                padding: EdgeInsets.all(10.0),
                animationDuration: Duration(milliseconds: 300),
                borderRadius: 10,
                onOpen: () => print('cell opened'),
                onClose: () => print('cell closed')),
          ),
        ],
      ),
    );
  }

  Widget FrontWidget() {
    return Container(
        color: Colors.blue,
//        alignment: Alignment.center,
        child: FutureBuilder(
            future: getEvents(),
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: Text("Loading ..."));
              } else
                return ListView.builder(
//                      shrinkWrap: false,
                    itemCount: snapshot.data.length,
                    itemBuilder: (_, index) {
                      {
                        return Row(
                          children: <Widget>[
                            Expanded(
                              flex: 1,
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15.0),
                                  color: Color(0xff6a53a4),
                                ),
                                child: Container(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          SizedBox(
                                            height: 9,
                                          ),
                                          Container(
                                              child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              snapshot.data[index].data["Jour"],
                                              style: TextStyle(
                                                  color: Color(0xFFc8b6ea),
                                                  fontSize: 20.0),
                                            ),
                                          )),
                                          Container(
                                              child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              snapshot
                                                  .data[index].data["Jour2"],
                                              style: TextStyle(
                                                  color: Color(0xFFc8b6ea),
                                                  fontSize: 20.0),
                                            ),
                                          )),
                                          Container(
                                              child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              snapshot
                                                  .data[index].data["Heure"],
                                              style: TextStyle(
                                                  color: Color(0xFFc8b6ea),
                                                  fontSize: 20.0),
                                            ),
                                          )),
                                          SizedBox(
                                            height: 8,
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 2,
                              child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15.0),
                                    color: Colors.grey[100],
                                  ),
                                  child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        SizedBox(
                                          height: 30,
                                        ),
                                        Container(
                                            child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                              snapshot
                                                  .data[index].data["Title"],
                                              style: TextStyle(
                                                color: Color(0xff6a53a4),
                                                fontSize: 24.0,
                                                fontWeight: FontWeight.bold,
                                              )),
                                        )),
                                        SizedBox(
                                          height: 12,
                                        ),
                                        FlatButton(
                                          onPressed: () => _foldingCellKey
                                              ?.currentState
                                              ?.toggleFold(),
                                          child: Text(
                                            "Détails",
                                          ),
                                          textColor: Colors.white,
                                          color: Colors.amber[700],
                                          splashColor:
                                              Colors.white.withOpacity(0.5),
                                        )
                                      ])),
                            ),
                          ],
                        );
                      }
                    });
            }));
  }

  Widget InnerBottomWidget() {
    return Container(
        color: Colors.white,
        child: FutureBuilder(
            future: getEvents(),
            builder: (_, snapshot) {
              return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (_, index) {
                    {
                      return Column(
                        children: <Widget>[
                          //Description
                          Container(
                            child: Row(
                              children: <Widget>[
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(FontAwesomeIcons.pen,
                                        color: new Color(0xffF7B928),
                                        size: 20.0),
                                  ),
                                ),
                                Container(
                                  width: 350,
                                  child: Text(
                                      snapshot.data[index].data["Description"],
                                      style: TextStyle(
                                        color: Colors.blueGrey,
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.bold,
                                      )),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),

                          //Button
                          FlatButton(
                            onPressed: () =>
                                _foldingCellKey?.currentState?.toggleFold(),
                            child: Text(
                              "Fermer",
                            ),
                            textColor: Colors.white,
                            color: Colors.amber[700],
                            splashColor: Colors.white.withOpacity(0.5),
                          ),
                        ],
                      );
                    }
                  });
            }));
  }

  Widget InnerTopWidget() {
    return Container(
        color: Color(0xff6a53a4),
        alignment: Alignment.center,
        child: FutureBuilder(
            future: getEvents(),
            builder: (_, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: Text("Loading ..."));
              } else
                return ListView.builder(
                    itemCount: snapshot.data.length,
                    itemBuilder: (_, index) {
                      {
                        return Container(
                            child: Column(children: <Widget>[
                          //Heading
                          Container(
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text("Details",
                                  style: TextStyle(
                                    color: Color(0xffF7B928),
                                    fontSize: 22.0,
                                    fontWeight: FontWeight.bold,
                                  )),
                            ),
                          ),

//                                tilte
                          Container(
                            child: Row(
                              children: <Widget>[
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(FontAwesomeIcons.mapMarkedAlt,
                                        color: new Color(0xffF7B928),
                                        size: 20.0),
                                  ),
                                ),
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(
                                        snapshot
                                            .data[index].data["Localisation"],
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.bold,
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          //Duration
                          Container(
                            child: Row(
                              children: <Widget>[
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(FontAwesomeIcons.clock,
                                        color: new Color(0xffF7B928),
                                        size: 20.0),
                                  ),
                                ),
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child:
                                        Text(snapshot.data[index].data["Durée"],
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.bold,
                                            )),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          //Price
                          Container(
                            child: Row(
                              children: <Widget>[
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Icon(FontAwesomeIcons.moneyBillAlt,
                                        color: new Color(0xffF7B928),
                                        size: 20.0),
                                  ),
                                ),
                                Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child:
                                        Text(snapshot.data[index].data["Prix"],
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.bold,
                                            )),
                                  ),
                                ),
                              ],
                            ),
                          )
                        ]));
                      }
                    });
            }));
  }
}

////////////
//FrondWidget(){
//  final _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
//
//  Future getEvents() async {
//    var firestore = Firestore.instance;
//    QuerySnapshot qn = await firestore.collection("Evenements").getDocuments();
//    return qn.documents;
//  }
//    return
//      Container(
//          color: Color(
//              0xffdfd4f4),
//          alignment: Alignment.center,
//          child: FutureBuilder(
//            future: getEvents(),
//            builder: (_, snapshot) {
//            if (snapshot.connectionState == ConnectionState.waiting) {
//            return Center(
//            child: Text(
//            "Loading ...")
//            );
//            }
//            else
//            return ListView.builder(
//             itemCount: snapshot.data.length,
//             itemBuilder: (_, index) {
//             {
//             return Row(
//              children: <Widget>[
//                Expanded(
//                  flex: 1,
//                  child: Container(
//                    decoration: BoxDecoration(
//                      borderRadius: BorderRadius.circular(
//                          15.0),
//                      color: Color(
//                          0xff6a53a4),
//                    ),
//                    child: Container(
//                      child: Row(
//                        mainAxisAlignment: MainAxisAlignment.center,
//                        children: <Widget>[
//                          Column(
//                            mainAxisAlignment: MainAxisAlignment.center,
//                            children: <Widget>[
//                              Container(
//                                  child: Padding(
//                                    padding: const EdgeInsets.all(
//                                        8.0),
//                                    child: Text(
//                                      snapshot.data[index].data["Jour"],
//
//                                      style: TextStyle(
//                                          color: Color(
//                                              0xFFc8b6ea),
//                                          fontSize: 20.0
//                                      ),
//                                    ),
//                                  )
//                              ),
//                              Container(
//                                  child: Padding(
//                                    padding: const EdgeInsets.all(
//                                        8.0),
//                                    child: Text(
//                                      snapshot.data[index].data["Jour2"],
//                                      style: TextStyle(
//                                          color: Color(
//                                              0xFFc8b6ea),
//                                          fontSize: 20.0
//                                      ),
//                                    ),
//                                  )
//                              ),
//                              Container(
//                                  child: Padding(
//                                    padding: const EdgeInsets.all(
//                                        8.0),
//                                    child: Text(
//                                      snapshot.data[index].data["Heure"],
//                                      style: TextStyle(
//                                          color: Color(
//                                              0xFFc8b6ea),
//                                          fontSize: 20.0
//                                      ),
//                                    ),
//                                  )
//                              ),
//                            ],
//                          )
//                        ],
//                      ),
//                    ),
//                  ),
//                ),
//                Expanded(
//                  flex: 2,
//                  child: Container(
//                      decoration: BoxDecoration(
//                        borderRadius: BorderRadius.circular(
//                            15.0),
//                        color: Colors.white,
//                      ),
//                      child: Column(
//                          mainAxisAlignment: MainAxisAlignment.center,
//                          children: <Widget>[
//                            Container(
//                                child: Padding(
//                                  padding: const EdgeInsets.all(
//                                      8.0),
//                                  child: Text(
//                                      snapshot.data[index].data ["Title"],
//                                      style: TextStyle(
//                                        color: Color(
//                                            0xff6a53a4),
//                                        fontSize: 20.0,
//                                        fontWeight: FontWeight.bold,
//                                      )
//                                  ),
//                                )
//                            ),
//                            FlatButton(
//                              onPressed: () =>
//                                  _foldingCellKey?.currentState?.toggleFold(
//                                  ),
//                              child: Text(
//                                "Détails",
//                              ),
//                              textColor: Colors.white,
//                              color: Colors.indigoAccent,
//                              splashColor: Colors.white.withOpacity(
//                                  0.5),
//                            )
//                          ]
//                      )
//                  ),
//                ),
//              ],
//            );
//          }}
//          );}
//  ));
//
//}
//
//
///////////////////
//InnerBottomWidgetState () {
//  final _foldingCellKey = GlobalKey<SimpleFoldingCellState>();
//  Future getEvents() async {
//    var firestore = Firestore.instance;
//    QuerySnapshot qn = await firestore.collection("Evenements").getDocuments();
//    return qn.documents;
//  }
//            return Container(
//                      color: Colors.white,
//                      alignment: Alignment.center,
//                child: FutureBuilder(
//                   future: getEvents(),
//                  builder: (_, snapshot) {
//                  if (snapshot.connectionState == ConnectionState.waiting) {
//                  return Center(
//                    child: Text(
//                    "Loading ...")
//                    );
//                    }
//                    else
//                    return ListView.builder(
//                    itemCount: snapshot.data.length,
//                    itemBuilder: (_, index) {
//                    {              return Container(
//                          child: Column(
//                children: <Widget>[
//                //Description
//                  Container(
//                    child: Row(
//                    children: <Widget>[
//                      Container(
//                        child: Padding(
//                           padding: const EdgeInsets.all(
//                          8.0),
//                          child: Icon(
//                            FontAwesomeIcons.pen,
//                            color: new Color(
//                            0xffF7B928),
//                            size: 20.0
//                            ),
//                  ),
//                ),
//                        Container(
//                        child: Padding(
//                        padding: const EdgeInsets.all(
//                             8.0),
//                           child: Text(
//                               snapshot.data[index].data["Description"],
//                            style: TextStyle(
//                            color: Colors.blueGrey,
//                            fontSize: 16.0,
//                            fontWeight: FontWeight.bold,
//                            )
//                            ),
//                            ),
//                            ),
//                            ],
//                            ),
//                    ),
//              SizedBox(
//              height: 80,),
//
//              //Button
//              FlatButton(
//              onPressed: () =>
//              _foldingCellKey?.currentState?.toggleFold(
//              ),
//              child: Text(
//              "Fermer",
//              ),
//              textColor: Colors.white,
//              color: Colors.amber[700],
//              splashColor: Colors.white.withOpacity(
//              0.5),
//              ),
//              ],
//              ),
//              ),
//            }}
//            )
//                    }));
//            }
//
///////////
//class InnerTopWidget extends StatefulWidget {
//  final DocumentSnapshot post;
//
//  const InnerTopWidget({Key key, this.post}) : super(key: key);
//  @override
//  _InnerTopWidgetState createState() => _InnerTopWidgetState();
//  }
//class _InnerTopWidgetState extends State< InnerTopWidget> {
//
//  @override
//  Widget build(BuildContext context) {
//  return
//    Container(
//      color: Color(
//          0xff6a53a4),
//      alignment: Alignment.center,
//      child: Container(
//        child: Column(
//          children: <Widget>[
//            //Heading
//            Container(
//              child: Padding(
//                padding: const EdgeInsets.all(
//                    8.0),
//                child: Text(
//                    "Details",
//                    style: TextStyle(
//                      color: new Color(
//                          0xffF7B928),
//                      fontSize: 22.0,
//                      fontWeight: FontWeight.bold,
//                    )
//                ),
//              ),
//            ),
//
//            //tilte
//            Container(
//              child: Row(
//                children: <Widget>[
//                  Container(
//                    child: Padding(
//                      padding: const EdgeInsets.all(8.0),
//                      child: Icon(
//                          FontAwesomeIcons.mapMarkedAlt,
//                          color: new Color(
//                              0xffF7B928),
//                          size: 20.0
//                      ),
//                    ),
//                  ),
//                  Container(
//                    child: Padding(
//                      padding: const EdgeInsets.all(
//                          8.0),
//                      child: Text(
//                          widget.post.data[ "Title"],
//                          style: TextStyle(
//                            color: Colors.white,
//                            fontSize: 16.0,
//                            fontWeight: FontWeight.bold,
//                          )
//                      ),
//                    ),
//                  ),
//                ],
//              ),
//            ),
//
//            //Duration
//            Container(
//              child: Row(
//                children: <Widget>[
//                  Container(
//                    child: Padding(
//                      padding: const EdgeInsets.all(
//                          8.0),
//                      child: Icon(
//                          FontAwesomeIcons.clock,
//                          color: new Color(
//                              0xffF7B928),
//                          size: 20.0
//                      ),
//                    ),
//                  ),
//                  Container(
//                    child: Padding(
//                      padding: const EdgeInsets.all(
//                          8.0),
//                      child: Text(
//                          widget.post.data["Durée"],
//                          style: TextStyle(
//                            color: Colors.white,
//                            fontSize: 16.0,
//                            fontWeight: FontWeight.bold,
//                          )
//                      ),
//                    ),
//                  ),
//                ],
//              ),
//            ),
//
//            //Price
//            Container(
//              child: Row(
//                children: <Widget>[
//                  Container(
//                    child: Padding(
//                      padding: const EdgeInsets.all(
//                          8.0),
//                      child: Icon(
//                          FontAwesomeIcons.moneyBillAlt,
//                          color: new Color(
//                              0xffF7B928),
//                          size: 20.0
//                      ),
//                    ),
//                  ),
//                  Container(
//                    child: Padding(
//                      padding: const EdgeInsets.all(
//                          8.0),
//                      child: Text(
//                          widget.post.data["Prix"],
//                          style: TextStyle(
//                            color: Colors.white,
//                            fontSize: 16.0,
//                            fontWeight: FontWeight.bold,
//                          )
//                      ),
//                    ),
//                  ),
//                ],
//              ),
//            ),
//          ],
//        ),
//      ),
//    );
//  }
//}

//import 'package:table_calendar/table_calendar.dart';
//import 'package:pfe/Evenements/Events_PopUp.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//
//
//final Map<DateTime, List> _holidays = {
//  DateTime(2020, 1, 1): ['Nouvel An'],
//  DateTime(2020, 1, 14): ['Fête de la Révolution'],
//  DateTime(2020, 3, 20): ['Fête de l’Indépendance'],
//  DateTime(2020, 5, 1): ['Fête du travail'],
//  DateTime(2020, 7, 25): ['Fête de la République'],
//};
//class Evenements extends StatefulWidget {
//  @override
//  _EvenementsState  createState() => _EvenementsState();
//}
//
//class _EvenementsState extends State<Evenements> with TickerProviderStateMixin {
//  Map<DateTime, List> _events;
//  List _selectedEvents;
//  AnimationController _animationController;
//  CalendarController _calendarController;
//  Event_PopUp _customDialog;
//
//  Future data;
//  Future getEvents() async {
//    var firestore = Firestore.instance;
//    QuerySnapshot qn = await firestore.collection("events").getDocuments(
//    );
//    return qn.documents;
//  }
//  @override
//  void initState() {
//    super.initState();
//    final _selectedDay = DateTime.now();
//    data = getEvents();
//    _selectedEvents = _events[_selectedDay] ?? [];
//    _calendarController = CalendarController();
//    _animationController = AnimationController(
//      vsync: this,
//      duration: const Duration(
//          milliseconds: 400),
//    );
//    _animationController.forward(
//    );
//  }
//
//  @override
//  void dispose() {
//    _animationController.dispose();
//    _calendarController.dispose();
//    super.dispose();
//  }
//
//  void _onDaySelected(DateTime date, List events, List holidays) {
//    print(
//        'CALLBACK: _onDaySelected');
//    setState(
//            () {
//          _selectedEvents = events;
//        });
//  }
//
//  void _onVisibleDaysChanged(DateTime first, DateTime last,
//      CalendarFormat format) {
//    print(
//        'CALLBACK: _onVisibleDaysChanged');
//    setState(
//            () {
//          _selectedEvents = [];
//        });
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      body: Column(
//        mainAxisSize: MainAxisSize.max,
//        children: <Widget>[
//          _buildTableCalendarWithBuilders(
//          ),
//          const SizedBox(
//              height: 20.0),
//          Expanded(
//              child: _buildEventList(
//              )),
//        ],
//      ),
//    );
//  }
//
//  Widget _buildTableCalendarWithBuilders() {
//    return Container(
//        child: FutureBuilder(
//            future: data,
//            builder: (_, snapshot)
//            {
//              if(snapshot.hasData) {
//                for (int i = 0; i <= snapshot.data.length; i++) {
//                    _events.addAll({snapshot.data[i]['date'] : snapshot.data[i]['name']});
//                    print(_events);
//                }
//                return TableCalendar(
//                  calendarController: _calendarController,
//                  events: _events,
//                  holidays: _holidays,
//                  initialCalendarFormat: CalendarFormat.month,
//                  formatAnimation: FormatAnimation.slide,
//                  startingDayOfWeek: StartingDayOfWeek.monday,
//                  availableGestures: AvailableGestures.all,
//                  availableCalendarFormats: const {
//                    CalendarFormat.month: '',
//                    CalendarFormat.week: '',
//                  },
//                  calendarStyle: CalendarStyle(
//                    outsideDaysVisible: false,
//                    weekendStyle: TextStyle(
//                    ).copyWith(
//                        color: Colors.red),
//                    holidayStyle: TextStyle(
//                    ).copyWith(
//                      color: Colors.red,),
//                  ),
//                  daysOfWeekStyle: DaysOfWeekStyle(
//                    weekendStyle: TextStyle(
//                    ).copyWith(
//                        color: Colors.red),
//                  ),
//                  headerStyle: HeaderStyle(
//                    centerHeaderTitle: true,
//                    formatButtonVisible: false,
//                    //        formatButtonTextStyle: TextStyle().copyWith(color: Colors.white, fontSize: 15.0),
//                    //        formatButtonDecoration: BoxDecoration().copyWith(
//                    //          color: Colors.deepPurple,
//                    //          borderRadius: BorderRadius.circular(16),
//                    //        ),
//                  ),
//                  builders: CalendarBuilders(
//                    selectedDayBuilder: (context, date, _) {
//                      return FadeTransition(
//                        opacity: Tween(
//                            begin: 0.0, end: 1.0).animate(
//                            _animationController),
//                        child: Container(
//                          margin: const EdgeInsets.all(
//                              4.0),
//                          padding: const EdgeInsets.only(
//                              top: 5.0, left: 6.0),
//                          color: Colors.deepOrange[300],
//                          width: 100,
//                          height: 100,
//                          child: Text(
//                            '${date.day}',
//                            style: TextStyle(
//                            ).copyWith(
//                                fontSize: 16.0),
//                          ),
//                        ),
//                      );
//                    },
//                    todayDayBuilder: (context, date, _) {
//                      return Container(
//                        margin: const EdgeInsets.all(
//                            4.0),
//                        padding: const EdgeInsets.only(
//                            top: 5.0, left: 6.0),
//                        color: Colors.amber[400],
//                        width: 100,
//                        height: 100,
//                        child: Text(
//                          '${date.day}',
//                          style: TextStyle(
//                          ).copyWith(
//                              fontSize: 16.0),
//                        ),
//                      );
//                    },
//                    markersBuilder: (context, date, events, holidays) {
//                      final children = <Widget>[];
//
//                      if (events.isNotEmpty) {
//                        children.add(
//                          Positioned(
//                            right: 1,
//                            bottom: 1,
//                            child: _buildEventsMarker(
//                                date, events),
//                          ),
//                        );
//                      }
//                      if (holidays.isNotEmpty) {
//                        children.add(
//                          Positioned(
//                            right: -2,
//                            top: -2,
//                            child: _buildHolidaysMarker(
//                            ),
//                          ),
//                        );
//                      }
//                      return children;
//                    },
//                  ),
//                  onDaySelected: (date, events) {
//                    List holidays;
//                    _onDaySelected(
//                        date, events, holidays);
//                    _animationController.forward(
//                        from: 0.0);
//                  },
//                  onVisibleDaysChanged: _onVisibleDaysChanged,
//                );
//              }
//              else
//                return Center(child: CircularProgressIndicator(),);
//            }
//    )
//    );
//  }
//
//  Widget _buildEventsMarker(DateTime date, List events) {
//    return AnimatedContainer(
//      duration: const Duration(
//          milliseconds: 300),
//      decoration: BoxDecoration(
//        shape: BoxShape.circle,
//        color: _calendarController.isSelected(
//            date)
//            ? Colors.brown[500]
//            : _calendarController.isToday(
//            date) ? Colors.brown[300] : Colors.purple[400],
//      ),
//      width: 16.0,
//      height: 16.0,
//      child: Center(
//        child: Text(
//          '${events.length}',
//          style: TextStyle(
//          ).copyWith(
//            color: Colors.white,
//            fontSize: 12.0,
//          ),
//        ),
//      ),
//    );
//  }
//
//  Widget _buildHolidaysMarker() {
//    return Icon(
//      Icons.add_box,
//      size: 20.0,
//      color: Colors.blueGrey[800],
//    );
//  }
//
//
//  Widget _buildEventList() {
//    return ListView(
//      children: _selectedEvents.map(
//              (event) =>
//              Container(
//                decoration: BoxDecoration(
//                  border: Border.all(
//                      width: 0.8),
//                  borderRadius: BorderRadius.circular(
//                      12.0),
//                ),
//                margin: const EdgeInsets.symmetric(
//                    horizontal: 8.0, vertical: 4.0),
//                child: ListTile(
//                    title: Text(
//                        event.toString(
//                        )),
//                    onTap: () =>
//                    _customDialog = new Event_PopUp(
//                      title: event.toString(),
//                      description: event.toString(),
//                      context: context,
//                      PopUp: AlertDialog(),
//                    )
//                ),
//              ))
//          .toList(
//      ),
//    );
//  }
//
//  // ignore: missing_return, non_constant_identifier_names
//  Future AlertDialog() {
//    showDialog(
//        barrierDismissible: false,
//        context: context,
//        builder: (BuildContext context) => _customDialog
//    );
//  }
//}
//
////_selectedDay.subtract(Duration(days: 30)): ['Event A0', 'Event B0', 'Event C0'],
////_selectedDay.subtract(Duration(days: 27)): ['Event A1'],
////_selectedDay.subtract(Duration(days: 20)): ['Event A2', 'Event B2', 'Event C2', 'Event D2'],
////_selectedDay.subtract(Duration(days: 16)): ['Event A3', 'Event B3'],
////_selectedDay.subtract(Duration(days: 10)): ['Event A4', 'Event B4', 'Event C4'],
////_selectedDay.subtract(Duration(days: 4)): ['Event A5', 'Event B5', 'Event C5'],
////_selectedDay.subtract(Duration(days: 2)): ['Event A6', 'Event B6'],
////_selectedDay: ['Event A7', 'Event B7', 'Event C7', 'Event D7'],
////_selectedDay.add(Duration(days: 1)): ['Event A8', 'Event B8', 'Event C8', 'Event D8'],
////_selectedDay.add(Duration(days: 3)): Set.from(['Event A9', 'Event A9', 'Event B9']).toList(),
////_selectedDay.add(Duration(days: 7)): ['Event A10', 'Event B10', 'Event C10'],
////_selectedDay.add(Duration(days: 11)): ['Event A11', 'Event B11'],
////_selectedDay.add(Duration(days: 17)): ['Event A12', 'Event B12', 'Event C12', 'Event D12'],
////_selectedDay.add(Duration(days: 22)): ['Event A13', 'Event B13'],
////_selectedDay.add(Duration(days: 26)): ['Event A14', 'Event B14', 'Event C14'],
