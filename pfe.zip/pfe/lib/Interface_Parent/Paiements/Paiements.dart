import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class Paiements extends StatefulWidget {
  @override
  _PaiementsState  createState() => _PaiementsState();
}

class _PaiementsState extends State<Paiements> {
  Future _data;
  Future getCalendrier() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection("Paiements").getDocuments(
    );
    return qn.documents;
  }
  @override
  void initState() {
    super.initState();
    _data = getCalendrier();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[350],
        title: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Image.asset(
                'assets/images/oschoo.png',
                fit: BoxFit.contain,
                height: 70,
                width: 90,
              ),
            ]
        ),
      ),
      body : new ListView(
          padding: EdgeInsets.only(top: 30),
          children: <Widget>[
            new Column(
              children: <Widget>[
                Text('Historique des paiements',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 25.0,
                      fontStyle: FontStyle.italic),)
              ],
            ),
            SizedBox(height: 20,),
            Container(
                  child: FutureBuilder(
                      future: _data,
                      builder: (_, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(
                              child: Text(
                                  "Loading ...")
                          );
                        } else
                          return ListView.builder(
                              itemCount: snapshot.data.length,
                              itemBuilder: (_, index) {
                                return Container(decoration: new BoxDecoration (
                                    color: snapshot.data[index].data['color'],
                                    border: Border.all(
                                      color: Colors.grey, //                   <--- border color
                                      width: 3,
                                    ),
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(10.0)
                                    )
                                ),
                                  margin: EdgeInsets.only(bottom: 1.0,left: 7.0,right: 7.0,top: 7.0),
                                  child: new ListTile (
                                      trailing: Icon(
                                        snapshot.data[index].data['icon'],
                                        size: 30.0,
                                        color: Colors.black,),
                                      title: Text(snapshot.data[index].data['mois'],
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20.0),)
                                  ),);                              });
                      }
                  )),
            ]));

//            buildPaymentItem(Colors.green, Icons.check_circle,"Septembre"),
//            buildPaymentItem(Colors.green, Icons.check_circle,"Octobre"),
//            buildPaymentItem(Colors.green, Icons.check_circle,"Novembre"),
//            buildPaymentItem(Colors.green, Icons.check_circle,"Décembre"),
//            buildPaymentItem(Colors.green, Icons.check_circle,"Janvier"),
//            buildPaymentItem(Colors.green, Icons.check_circle,"Février"),
//            buildPaymentItem(Colors.red, Icons.lock_open,"Mars"),
//            buildPaymentItem(Colors.orange[400], Icons.lock,"Avril"),
//            buildPaymentItem(Colors.orange[400], Icons.lock,"Mai"),
//            buildPaymentItem(Colors.orange[400], Icons.lock,"Juin"),


  }}

//buildPaymentItem( Color color, IconData icon, String mois ) {
//  return Container(decoration: new BoxDecoration (
//      color: color,
//      border: Border.all(
//        color: Colors.grey, //                   <--- border color
//        width: 3,
//      ),
//      borderRadius: BorderRadius.all(
//          Radius.circular(10.0)
//      )
//  ),
//    margin: EdgeInsets.only(bottom: 1.0,left: 7.0,right: 7.0,top: 7.0),
//    child: new ListTile (
//        trailing: Icon(icon, size: 30.0,color: Colors.black,),
//        title: Text(mois, style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20.0),)
//    ),);
//}


