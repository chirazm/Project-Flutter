import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pfe/Interface_Parent/Emploi/constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Calendar extends StatefulWidget {
  @override
  _CalendarState createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> with TickerProviderStateMixin {
  Future _data;

  Future getCalendrier() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection("Calendrier").getDocuments();
    return qn.documents;
  }

  @override
  void initState() {
    super.initState();
    _data = getCalendrier();
  }

  createAlertDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
              backgroundColor: Colors.transparent,
              content: Builder(
                builder: (context) {
                  return Container(
                    height: 500,
                    width: 400,
                    child: dialogContent(context),
                  );
                },
              ));
        });
  }

  Widget build(BuildContext context) {
    return Column(children: <Widget>[
      Expanded(
        child: Container(
            child: SizedBox(
          height: 70,
          child: new ListView(
              padding: EdgeInsets.only(top: 30),
              children: <Widget>[
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 8,
                    ),
                    Icon(
                      Icons.book,
                      color: Colors.black,
                      size: 25.0,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text("Emploi du temps",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20.0,
                          fontWeight: FontWeight.bold,
                        )),
                    SizedBox(
                      width: 49,
                    ),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.assignment_ind,
                          color: Colors.black,
                          size: 25.0,
                        ),
                        new FlatButton(
                          onPressed: () {
                            createAlertDialog(context);
                          },
                          child: new Text("Enseignants",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 20.0,
                                fontWeight: FontWeight.bold,
                              )),
                        )
                      ],
                    )
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
              ]),
        )),
      ),
      Container(
        child: SizedBox(
            height: 530,
            child: FutureBuilder(
                future: _data,
                builder: (_, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: Text("Loading ..."));
                  } else
                    return ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (_, index) {
                          return Container(
                            margin: EdgeInsets.only(
                                top: 18, right: 12, left: 12, bottom: 10),
                            padding: EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              color: Colors.purple,
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: Container(
                              margin: EdgeInsets.all(5),
                              padding: EdgeInsets.all(20),
                              height: 210,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            Text(
                                                snapshot.data[index].data[
                                                    "Day1" ?? 'default value'],
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 18.0,
                                                  fontWeight: FontWeight.bold,
                                                )),
                                            Text(
                                                snapshot.data[index].data[
                                                    "Day2" ?? 'default value'],
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 18.0,
                                                  fontWeight: FontWeight.bold,
                                                )),
                                          ]),
                                      SizedBox(
                                        height: 12,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: <Widget>[
                                                Icon(
                                                  Icons.access_time,
                                                  color: Colors.black,
                                                  size: 18,
                                                ),
                                                Icon(
                                                  Icons.border_color,
                                                  color: Colors.black,
                                                  size: 18,
                                                ),
                                                Icon(
                                                  Icons.home,
                                                  color: Colors.black,
                                                  size: 18,
                                                ),
                                              ]),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index].data[
                                                    "time1" ?? 'default value'],
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index].data[
                                                    "mat1" ?? 'default value'],
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index].data[
                                                    "cl1" ?? 'default value'],
                                                style: CalendarDay),
                                          ]),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index].data[
                                                    "time2" ?? 'default value'],
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index].data[
                                                    "mat2" ?? 'default value'],
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index].data[
                                                    "cl2" ?? 'default value'],
                                                style: CalendarDay),
                                          ]),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index].data[
                                                    "time3" ?? 'default value'],
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index].data[
                                                    "mat3" ?? 'default value'],
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index].data[
                                                    "cl3" ?? 'default value'],
                                                style: CalendarDay),
                                          ]),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index]
                                                        .data["time4"] ??
                                                    'default value',
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index]
                                                        .data["mat4"] ??
                                                    'default value',
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index]
                                                        .data["cl4"] ??
                                                    'default value',
                                                style: CalendarDay),
                                          ])
                                        ],
                                      ),
                                      Divider(
                                        color: Colors.purple,
                                        thickness: 5,
                                        height: 14,
                                        indent: 10,
                                        endIndent: 10,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Column(),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index]
                                                        .data["time5"] ??
                                                    'default value',
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index]
                                                        .data["mat5"] ??
                                                    'default value',
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index]
                                                        .data["cl5"] ??
                                                    'default value',
                                                style: CalendarDay),
                                          ]),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index]
                                                        .data["time6"] ??
                                                    'default value',
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index]
                                                        .data["mat6"] ??
                                                    'default value',
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index]
                                                        .data["cl6"] ??
                                                    'default value',
                                                style: CalendarDay),
                                          ]),
                                          Column(children: <Widget>[
                                            Text(
                                                snapshot.data[index]
                                                        .data["time7"] ??
                                                    'default value',
                                                style: TitleColor),
                                            Text(
                                                snapshot.data[index]
                                                        .data["mat7"] ??
                                                    'default value',
                                                style: CalendarDay),
                                            Text(
                                                snapshot.data[index]
                                                        .data["cl7"] ??
                                                    'default value',
                                                style: CalendarDay),
                                          ]),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ]),
                            ),
                          );
                        });
                })),
      )
    ]);
  }
}

CalendrierDetails(BuildContext _context) {
  Future getEnseignants() async {
    var firestore = Firestore.instance;
    QuerySnapshot qn = await firestore.collection("Enseignants").getDocuments();
    return qn.documents;
  }

  return Container(
      child: Column(
    children: <Widget>[
      Row(
        children: <Widget>[
          Icon(Icons.group),
          SizedBox(
            width: 5,
          ),
          Text(
            'Ses Enseignants :',
            style: TextStyle(
                fontSize: 20, color: Colors.black, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 5,
          )
        ],
      ),
      SizedBox(
        width: 12,
      ),
      Divider(
        color: Colors.purple,
        thickness: 4,
        height: 10,
      ),
      SizedBox(
        height: 20,
      ),
      Container(
        child: SizedBox(
          height: 300,
          child: FutureBuilder(
              future: getEnseignants(),
              builder: (_, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: Text("Loading ..."));
                } else
                  return ListView.builder(
                      itemCount: snapshot.data.length,
                      itemBuilder: (_, index) {
                        return Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                            Column(
                              children: <Widget>[
                                new Text(
                                  snapshot.data[index]
                                      .data["name" ?? 'default value'],
                                ),
                                SizedBox(
                                  height: 20,
                                )
                              ],
                            ),
                          ],
                        );
                      });
              }),
        ),
      ),
      RaisedButton(
        onPressed: Navigator.of(_context).pop,
        textColor: Colors.white,
        padding: const EdgeInsets.all(0.0),
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: <Color>[
                Color(0xFF4A148C),
                Color(0xFF7B1FA2),
                Color(0xFFAB47BC),
              ],
            ),
          ),
          padding: const EdgeInsets.all(10.0),
          child: const Text('Fermer', style: TextStyle(fontSize: 20)),
        ),
      ),
    ],
  ));
}

dialogContent(BuildContext context) {
  Widget cardPart = Container(
    padding: EdgeInsets.only(
      top: 40,
      bottom: 50,
      left: 20,
      right: 20,
    ),
//    margin: EdgeInsets.only(top: 40),
    decoration: new BoxDecoration(
      border: Border.all(color: Colors.black, width: 2),
      color: Colors.white,
      borderRadius: BorderRadius.circular(30),
    ),
    child: CalendrierDetails(context),
  );
  return Stack(
    children: <Widget>[
      cardPart,
      Positioned.fill(
          child: Align(
        alignment: Alignment.topRight,
      ))
    ],
  );
}

DividerItem() {
  return Divider(
    color: Colors.grey,
    thickness: 2,
    height: 6,
  );
}
