import 'package:flutter/material.dart';

const CardColor = Color(0xFF282B30);
const HourColor = Color(0xFFF5C35A);
const BGColor = Color(0xFF343537);

const TextColor = Color(0xFF424242);
const TitleColor =TextStyle(
    color: Colors.purple,
    fontSize: 16,
    fontWeight: FontWeight.bold
);
const CalendarDay = TextStyle(
  color: TextColor,
  fontSize: 14.0,
);