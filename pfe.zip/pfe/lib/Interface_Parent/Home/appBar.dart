import 'package:flutter/material.dart';
class AppBarWidgets extends StatelessWidget {
  final String name ;
  final void onPressed;
  AppBarWidgets(
      {
        @required this.name,
        @required this.onPressed
      });
  @override
  Widget build(BuildContext context) {

    return
      Container(
        padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
        child: InkWell(
          child: CircleAvatar(
            backgroundImage: AssetImage('assets/images/Ahmed.jpg'),
            backgroundColor: Colors.deepPurple,
          ),
          onTap: (){},
        ),
      );
  }
}

