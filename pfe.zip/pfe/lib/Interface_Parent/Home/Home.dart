import 'package:pfe/Interface_Parent/A_propos//A_propos.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Identification.dart';
import 'package:flutter/cupertino.dart';
import 'package:pfe/Interface_Parent/Home/appBar.dart';
import 'package:pfe/Interface_Parent/authentification/auth.dart';
import 'package:pfe/Interface_Parent/message/message.dart';
import 'package:pfe/Interface_Parent/msg/all_attendees.dart';
import 'package:pfe/Interface_Parent/Messages/Message.dart';
import 'package:pfe/Interface_Parent/Paiements/Paiements.dart';
import '../Emploi/Calendrier.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Ajouter_Ecole.dart';
import 'package:pfe/Interface_Parent/Notes/Notes.dart';
import 'package:pfe/Interface_Parent/Notifications/Notifications.dart';
import 'package:pfe/Interface_Parent/cours/Cours.dart';
import 'package:pfe/Interface_Parent/Evenements/Evenements.dart';
import 'package:pfe/Interface_Parent/Messages/Search.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final AuthService _auth = AuthService();
  int _currentIndex = 0;
  final List<Widget> _children = [
    Calendar(),
    Evenements(),
    Notifications(),
    Search(),
    Cours(),
    //    Paiements(),
  ];

  void onTappedBar(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    int n = 6;

    List<Widget> list = new List();
    for (int i = 0; i <= n; i++) {
      list.add(AppBarWidgets(
        name: n.toString(),
        onPressed: () {},
      ));
    }
    Widget listView = ListView(
      reverse: true,
      scrollDirection: Axis.horizontal,
      children: list,
    );

    // ignore: unnecessary_statements
    _children[_currentIndex];
    Widget _flexibleSpace = Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[350],
        actions: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 2, bottom: 1),
            child: Container(
                padding: EdgeInsets.only(
                  right: 8,
                  left: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.deepPurple,
                  borderRadius: BorderRadius.circular(30),
                ),
                alignment: Alignment.centerRight,
                height: 40,
                width: 230,
                child: listView),
          ),
        ],
        title: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          Image.asset(
            'assets/images/oschoo.png',
            fit: BoxFit.contain,
            height: 70,
            width: 90,
          ),
        ]),
      ),
      drawer: new Drawer(
          child: new ListView(
        children: <Widget>[
          new UserAccountsDrawerHeader(
            accountName: new Text(
              "Mzali Rania",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            accountEmail: new Text("mzalirania@hotmail.com"),
            currentAccountPicture: new CircleAvatar(
              backgroundColor: Colors.grey[200],
              backgroundImage: AssetImage('assets/images/utilisateur.jpg'),
            ),
          ),
          new ListTile(
            title: new Text(
              "Ajouter école",
              style: TextStyle(fontSize: 17),
            ),
            trailing: new Icon(Icons.home),
            onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => new AjouterEcole())),
          ),
          new ListTile(
            title: new Text("Notes", style: TextStyle(fontSize: 17)),
            trailing: new Icon(Icons.description),
            onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => new Note())),
          ),
          new ListTile(
            title: new Text("Paiements", style: TextStyle(fontSize: 17)),
            trailing: new Icon(Icons.payment),
            onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => new Paiements())),
          ),
          new Divider(
            color: Colors.black45,
            indent: 17,
          ),
          new ListTile(
            title: new Text("Paramétres", style: TextStyle(fontSize: 17)),
            trailing: new Icon(Icons.settings),
          ),
          new ListTile(
            title: new Text("A propos", style: TextStyle(fontSize: 17)),
            trailing: new Icon(Icons.error),
            onTap: () => Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => new AboutUs())),
          ),
          new Divider(
            color: Colors.black45,
            indent: 17,
          ),
          new ListTile(
              title: new Text("Déconnexion", style: TextStyle(fontSize: 17)),
              trailing: new Icon(Icons.exit_to_app),
              onTap: () async {
                await _auth.signOut();
              }),
        ],
      )),
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTappedBar,
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.calendar_today,
              size: 30,
            ),
            title: Text(
              'Calendrier',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.event,
              size: 30,
            ),
            title: Text(
              'Evénements',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.notifications,
              size: 30,
            ),
            title: Text(
              'Notifications',
              style: TextStyle(fontSize: 18.0),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.mail,
              size: 30,
            ),
            title: Text(
              'Messages',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.picture_as_pdf,
              size: 30,
            ),
            title: Text(
              'Cours',
              style: TextStyle(fontSize: 17.0),
            ),
          ),
        ],
        unselectedItemColor: Colors.purple[300],
        selectedItemColor: Colors.purple.shade800,
        showUnselectedLabels: true,
        showSelectedLabels: true,
        backgroundColor: Colors.grey[400],
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedFontSize: 17.0,
        unselectedFontSize: 15.0,
      ),
      body: _children[_currentIndex],
    );
    return _flexibleSpace;
  }
}
