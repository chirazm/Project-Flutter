import 'package:flutter/cupertino.dart';
import 'package:pfe/Accueil/utilisateur.dart';
import 'file:///C:/Users/meddeb%20chiraz/.android/avd/pfe/lib/Identification/Identification.dart';
import 'package:provider/provider.dart';
class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<User>(context);
    print(User);
    return Identification();
  }
}
